#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_ask_apply.py  --  paper fills: also fill when the ask passes below the bid   (Fable, 17 Nov)

    python paper_ask_apply.py gate_v903i-11_A.py              -> writes gate_v903i-11_A.ask.py
    python paper_ask_apply.py gate_v903i-11_A.py out.py

Needs gate_v903i-11 (paper prints + settlement + freshness + arm-from-open).
Four anchored edits.  Every anchor must be found EXACTLY once -- otherwise it
stops and writes nothing.  The result must compile, or nothing is written.
"""
import sys

# ------------------------------------------------------------------ edit 1: settings
A1 = 'DATA_API_TRADES    = "https://data-api.polymarket.com/v2/trades"\n'
N1 = r'''# ---- THE ASK PASSED BELOW OUR BID (Fable, 17 Nov) ----------------------------------------------------------------------------------
# The print rule alone MISSES fills.  In a fast fall the quotes drop with no trades, because nobody else leaves a bid up there -- so no
# print ever goes through our price.  A live bid would be taken at once: any seller (or any buyer of the other outcome) gets a better
# price from us than from the book.  Live history, 27 Sep - 10 Nov, 13,282 orders: of 10,283 live bids that were NOT filled, the ask was
# 1c or more below the bid at some poll in only 35 (0.3%).  Paper, 15-17 Nov: 99 of 430 bids were passed like that and never filled.
# So a paper bid now fills on real prints (as before) OR when the ask (1 - the other side's best bid) is PAPER_ASK_GAP below our price.
PAPER_ASK_THROUGH = True      # False = prints only, as v9.03i-4 .. i-11
PAPER_ASK_GAP     = 0.01      # the ask must be at least this far BELOW our bid (at our price exactly, only prints decide: the queue)
PAPER_ASK_POLLS   = 1         # on this many polls in a row
PAPER_ASK_MAX_AGE = 5.0       # the prices must be no older than this (seconds)
''' + A1

# ------------------------------------------------------------------ edit 2: the method
A2 = '    def _paper_fallback_note(self, b) -> None:\n'
N2 = r'''    def _paper_ask_through(self, b, snap) -> bool:
        """Paper: the ask is below our resting bid -- a live bid would have been taken.  Logs a paper_ask_fill row.  Never raises."""
        if not PAPER_ASK_THROUGH:
            return False
        try:
            t0 = _PAPER_T0.get(b.get("order_id")) or b.get("paper_t0")
            if t0 is None or time.time() - t0 < PAPER_SKEW_START:
                return False
            f = getattr(self, "feed", None)
            if f is not None and f.age() > PAPER_ASK_MAX_AGE:
                return False
            ob = (snap or {}).get(b["coin"], {}).get(DOWN if b.get("fade_dir") == UP else UP)
            if ob is None:
                return False
            ask = round(1.0 - float(ob), 2)
            if ask > float(b["limit"]) - PAPER_ASK_GAP + 1e-9:
                b["_ask_n"] = 0
                return False
            b["_ask_n"] = b.get("_ask_n", 0) + 1
            if b["_ask_n"] < PAPER_ASK_POLLS:
                return False
            self.paper_ask_fills = getattr(self, "paper_ask_fills", 0) + 1
            log_csv(ts=now_ts(), period_start=TOKEN_TF.get(str(b.get("token_id")), (0, ""))[1], coin=b["coin"], src=b.get("src", ""),
                    fade_dir=b.get("fade_dir"), limit=b["limit"], action="paper_ask_fill", order_id=b.get("order_id"),
                    price=ask, shares=b.get("shares"), status="paper",
                    note="ask %.2f is below our bid %.2f, no print through it yet -- filled as a live bid would be (rested %d s)" % (
                        ask, float(b["limit"]), int(time.time() - t0)))
            return True
        except Exception:               # noqa: BLE001
            return False

''' + A2

# ------------------------------------------------------------------ edits 3 + 4: the two paper fill loops
A3 = ('                    _ok, _ts, _sz = self._paper_print_check(b)\n'
      '                    if _ok:\n'
      '                        b["paper_done"] = True\n'
      '                        self._book_fill(key, b, float(b.get("shares") or SHARES))\n')
N3 = ('                    _ok, _ts, _sz = self._paper_print_check(b)\n'
      '                    if not _ok:\n'
      '                        _ok = self._paper_ask_through(b, snap)            # no print through us, but the ask is below our bid -- see PAPER_ASK_THROUGH\n'
      '                    if _ok:\n'
      '                        b["paper_done"] = True\n'
      '                        self._book_fill(key, b, float(b.get("shares") or SHARES))\n')
A4 = ('                    _ok, _ts, _sz = self._paper_print_check(b)\n'
      '                    if _ok:\n'
      '                        b["paper_done"] = True\n'
      '                        self._book_fill_five(b, float(b.get("shares") or BASE_SHARES))\n')
N4 = ('                    _ok, _ts, _sz = self._paper_print_check(b)\n'
      '                    if not _ok:\n'
      '                        _ok = self._paper_ask_through(b, snap5)           # no print through us, but the ask is below our bid -- see PAPER_ASK_THROUGH\n'
      '                    if _ok:\n'
      '                        b["paper_done"] = True\n'
      '                        self._book_fill_five(b, float(b.get("shares") or BASE_SHARES))\n')

EDITS = [("edit 1 (settings)", A1, N1), ("edit 2 (method)", A2, N2), ("edit 3 (15m fill loop)", A3, N3), ("edit 4 (5m fill loop)", A4, N4)]


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else (src[:-3] if src.endswith(".py") else src) + ".ask.py"
    s = open(src, encoding="utf-8").read()
    if "PAPER_ASK_THROUGH" in s:
        sys.exit("STOP: this file already has the ask-through patch. Nothing written.")
    for need in ("PAPER_SKEW_START", "_PAPER_T0", "TOKEN_TF", "def _paper_print_check("):
        if need not in s:
            sys.exit("STOP: %r not in the file -- this needs the paper-prints build (v9.03i-4 or later). Nothing written." % need)
    for what, a, _n in EDITS:
        if s.count(a) != 1:
            sys.exit("STOP: anchor for %s found %d times (need exactly 1). Nothing written." % (what, s.count(a)))
    for _what, a, n in EDITS:
        s = s.replace(a, n, 1)
    compile(s, dst, "exec")
    open(dst, "w", encoding="utf-8", newline="\n").write(s)
    print("ok: 4 edits ->", dst)


if __name__ == "__main__":
    main()
