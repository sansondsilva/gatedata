#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_ask_validate.py  --  are paper bids still being passed without a fill?   (Fable, 17 Nov)

    python paper_ask_validate.py gatetrades.csv gateticks5m.csv gateticks.csv
    python paper_ask_validate.py gatetrades.csv gateticks5m.csv gateticks.csv --since "2026-11-17 06:00"

For every paper bid (place_buy) it follows the ask (1 - the other side's best bid, from the tick files)
while the bid rested, and prints:
  1. FILLS        by prints / by the ask passing below the bid (paper_ask_fill rows), and how each group did
  2. PASSED, NOT FILLED   bids the ask went 1c+ below (4 s or more after placing) that never filled.
                  Live history: 0.3% of unfilled bids.  Old paper (15-17 Nov): 99 of 430 bids.  Target: about 0.
  3. BY LEG       fills and wins
"Won" = the bid's side was ahead at the last tick of its window (a rough result, not the ledger's P&L).
"""
import argparse, csv, gzip, sys
from collections import defaultdict
from datetime import datetime, timezone

F15 = {"rock15", "xsma15", "xsma15-b", "bb15", "opal15", "prime15", "gold15", "turn-15", "prime15-35", "penny", "wide"}
COINS = ("btc", "eth", "sol", "xrp")


def rd(fn):
    op = gzip.open if fn.endswith(".gz") else open
    with op(fn, "rt", encoding="utf-8", errors="replace", newline="") as f:
        return list(csv.DictReader(f))


def fnum(x):
    try:
        v = float(x)
        return v if v == v else None
    except Exception:
        return None


def to_ts(s):
    if not s:
        return None
    if s.isdigit():
        return int(s)
    for fm in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return int(datetime.strptime(s, fm).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            pass
    sys.exit("bad time: " + s)


def load_ticks(fn):
    out = defaultdict(list)             # period -> [(ts, {coin_side: bid})]
    for r in rd(fn):
        ts, P = fnum(r.get("ts")), fnum(r.get("period_start"))
        if ts is None or P is None:
            continue
        out[int(P)].append((int(ts), {k: fnum(r.get(k)) for c in COINS for k in (c + "_up", c + "_dn")}))
    for P in out:
        out[P].sort(key=lambda x: x[0])
    return out


def pct(a, b):
    return "%5.1f%%" % (100.0 * a / b) if b else "    - "


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("ledger"); ap.add_argument("ticks5m"); ap.add_argument("ticks15m")
    ap.add_argument("--since"); ap.add_argument("--until")
    ap.add_argument("--gap", type=float, default=0.01, help="the ask must be this far below the bid (default 0.01)")
    ap.add_argument("--list", action="store_true", help="list the bids that were passed and not filled")
    a = ap.parse_args()
    lo, hi = to_ts(a.since), to_ts(a.until)
    T = {300: load_ticks(a.ticks5m), 900: load_ticks(a.ticks15m)}
    rows = [r for r in rd(a.ledger) if fnum(r.get("ts")) is not None]
    ends = defaultdict(list); askfill = set()
    for r in rows:
        act = r.get("action")
        P = fnum(r.get("period_start"))
        if P is None:
            continue
        k = (int(P), r.get("coin"), r.get("src"), r.get("fade_dir"))
        if act in ("fill", "cancel", "order_dead"):
            ends[k].append((int(float(r["ts"])), act))
        elif act == "paper_ask_fill":
            askfill.add((k, r.get("order_id") or ""))
            askfill.add((k, ""))
    bids = []
    for r in rows:
        if r.get("action") != "place_buy" or not str(r.get("order_id", "")).startswith("DRY"):
            continue
        ts, P, lim = int(float(r["ts"])), fnum(r.get("period_start")), fnum(r.get("limit"))
        if P is None or lim is None or (lo and ts < lo) or (hi and ts >= hi):
            continue
        P = int(P); src = r.get("src") or ""
        base = src[:-2] if src.endswith("-r") else src
        tf = 900 if (base in F15 or "15" in base) else 300
        if P not in T[tf] and P in T[1200 - tf]:
            tf = 1200 - tf
        tk = T[tf].get(P)
        if not tk:
            continue
        k = (P, r.get("coin"), src, r.get("fade_dir"))
        e = sorted(x for x in ends.get(k, []) if x[0] >= ts)
        end, te = (e[0][1], e[0][0]) if e else ("none", P + tf)
        c = (r.get("coin") or "").lower()
        if c not in COINS:
            continue
        own, opp = c + ("_up" if r.get("fade_dir") == "UP" else "_dn"), c + ("_dn" if r.get("fade_dir") == "UP" else "_up")
        mn = None
        for t, px in tk:
            if ts + 4 <= t <= te and px.get(opp) is not None:
                v = 1.0 - px[opp]
                mn = v if mn is None else min(mn, v)
        last = tk[-1][1]
        won = (last.get(own) or 0.0) > (last.get(opp) or 0.0)
        by_ask = end == "fill" and ((k, r.get("order_id") or "") in askfill or ((k, "") in askfill and not r.get("order_id")))
        bids.append({"ts": ts, "leg": base, "src": src, "coin": r.get("coin"), "dir": r.get("fade_dir"), "limit": lim, "end": end,
                     "minask": mn, "passed": mn is not None and mn <= lim - a.gap + 1e-9, "won": won, "by_ask": by_ask})
    if not bids:
        sys.exit("no paper bids found")
    hm = lambda t: datetime.fromtimestamp(t, timezone.utc).strftime("%d %b %H:%M")
    print("paper bids: %d    %s -> %s UTC" % (len(bids), hm(min(b["ts"] for b in bids)), hm(max(b["ts"] for b in bids))))

    def line(v):
        return "%4d   side won %3d (%s)" % (len(v), sum(1 for b in v if b["won"]), pct(sum(1 for b in v if b["won"]), len(v)).strip())
    f = [b for b in bids if b["end"] == "fill"]
    print("\n1. FILLS")
    print("  all fills                   " + line(f))
    print("  by prints                   " + line([b for b in f if not b["by_ask"]]))
    print("  by the ask below the bid    " + line([b for b in f if b["by_ask"]]))
    miss = [b for b in bids if b["passed"] and b["end"] != "fill"]
    print("\n2. PASSED, NOT FILLED (the ask went %.0fc+ below the bid while it rested)" % (a.gap * 100))
    print("  %d of %d bids (%s)      target: about 0      their sides: %s"
          % (len(miss), len(bids), pct(len(miss), len(bids)).strip(), line(miss).split("   ", 1)[1]))
    if a.list:
        for b in sorted(miss, key=lambda b: b["ts"]):
            print("    %s  %-4s %-11s %-4s  bid %.2f  lowest ask %.2f  %s" % (hm(b["ts"]), b["coin"], b["src"], b["dir"], b["limit"], b["minask"], "won" if b["won"] else "lost"))
    print("\n3. BY LEG")
    print("  leg            bids   fills   by ask   side won   passed, not filled")
    legs = defaultdict(list)
    for b in bids:
        legs[b["leg"]].append(b)
    for leg, v in sorted(legs.items(), key=lambda kv: -len(kv[1])):
        fl = [b for b in v if b["end"] == "fill"]
        print("  %-13s %5d   %5d   %6d   %3d %s   %5d" % (leg, len(v), len(fl), sum(1 for b in fl if b["by_ask"]), sum(1 for b in fl if b["won"]),
                                                        pct(sum(1 for b in fl if b["won"]), len(fl)), sum(1 for b in v if b["passed"] and b["end"] != "fill")))


if __name__ == "__main__":
    main()
