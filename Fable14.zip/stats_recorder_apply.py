#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stats_recorder_apply.py  --  loop stats in the ledger + the 25c touch recorder   (Fable, 17 Nov)

    python stats_recorder_apply.py gate_v903i-12_A.py              -> writes gate_v903i-12_A.rec.py
    python stats_recorder_apply.py gate_v903i-12_A.py out.py

Run it on gate_v903i-11 AFTER paper_ask_apply.py.
Three anchored edits.  Every anchor must be found EXACTLY once, and the block
that is replaced must be byte-for-byte the i-11 one -- otherwise it stops and
writes nothing.  The result must compile, or nothing is written.

No new files: both changes write rows into gatetrades.csv only.
"""
import hashlib
import sys

# ------------------------------------------------------------------ edit 1: settings
A1 = ('LOOP_LOG         = True\n'
      'LOOP_LOG_MIN     = 4.0       # seconds: loops at least this long are written to LOOP_FILE\n'
      'LOOP_FILE        = "gateloop.csv"\n')
N1 = ('LOOP_LOG         = True      # one "loop_stats" row every LOOP_STATS_EVERY seconds in gatetrades.csv (gateloop.csv is no longer written)\n'
      'LOOP_STATS_EVERY = 300\n'
      'TOUCH_REC        = True      # the 25c touch recorder: one "touch25" row per window x coin x side that reached TOUCH_REC_PX (5m and 15m)\n'
      'TOUCH_REC_PX     = 0.25\n'
      'TOUCH_REC_LEFT   = 60        # a first touch counts only with at least this many seconds left (PRIME / GOLD pull their bids then)\n')

# ------------------------------------------------------------------ edit 2: loop_log_end replaced, the recorder added
S2 = 'def loop_log_end(ts, loop_t0) -> None:\n'
E2 = 'def paper_book(token_id):\n'
H2 = '4dec9598'
N2 = r'''_LS = {"b": None, "n": 0, "n4": 0, "n5": 0, "mx": 0.0, "omx": 0.0, "tot": 0.0, "bef": 0.0, "pr": 0.0, "aft": 0.0,
       "k_n": 0, "k_s": 0.0, "h_n": 0, "h_s": 0.0, "fr_n": 0, "fr_s": 0.0}


def loop_log_end(ts, loop_t0) -> None:
    """LOOP STATS: add this poll to the running totals; when the LOOP_STATS_EVERY bucket turns, write ONE
    "loop_stats" row for the bucket that just ended.  Seconds are totals over the bucket.  Never raises."""
    try:
        if not LOOP_LOG:
            return
        total = time.time() - loop_t0
        b = int(loop_t0) // LOOP_STATS_EVERY
        if _LS["b"] is not None and b != _LS["b"] and _LS["n"]:
            log_csv(ts=now_ts(), period_start=_LS["b"] * LOOP_STATS_EVERY, action="loop_stats", src="loop", status=str(_LS["n"]),
                    note=("polls=%d ge4=%d ge5=%d max=%.1f open_max=%.1f total=%.1f before=%.1f prices=%.1f after=%.1f "
                          "kl=%d/%.1f http=%d/%.1f fresh=%d/%.1f") % (
                        _LS["n"], _LS["n4"], _LS["n5"], _LS["mx"], _LS["omx"], _LS["tot"], _LS["bef"], _LS["pr"], _LS["aft"],
                        _LS["k_n"], _LS["k_s"], _LS["h_n"], _LS["h_s"], _LS["fr_n"], _LS["fr_s"]))
            for k in _LS:
                _LS[k] = 0 if isinstance(_LS[k], int) else 0.0
        _LS["b"] = b
        before = max(0.0, (_LT["feed_t"] - loop_t0) if _LT["feed_t"] else 0.0)
        _LS["n"] += 1
        _LS["n4"] += 1 if total >= 4.0 else 0
        _LS["n5"] += 1 if total >= 5.0 else 0
        _LS["mx"] = max(_LS["mx"], total)
        if int(loop_t0) % 300 < 15:                      # the slowest poll that STARTED in the first 15 s of a 5m window
            _LS["omx"] = max(_LS["omx"], total)
        _LS["tot"] += total; _LS["bef"] += before; _LS["pr"] += _LT["feed_s"]
        _LS["aft"] += max(0.0, total - before - _LT["feed_s"])
        _LS["k_n"] += _LT["k_n"]; _LS["k_s"] += _LT["k_s"]
        _LS["h_n"] += max(0, _LT["h_n"] - _LT["k_n"]); _LS["h_s"] += max(0.0, _LT["h_s"] - _LT["k_s"])
        _LS["fr_n"] += _LT["fr_n"]; _LS["fr_s"] += _LT["fr_s"]
    except Exception:           # noqa: BLE001
        pass


# ==============================================================================
# THE 25c TOUCH RECORDER   (Fable / operator, 17 Nov)
# ------------------------------------------------------------------------------
# One "touch25" row per window x coin x side whose ask (1 - the other side's best
# bid) reached TOUCH_REC_PX with TOUCH_REC_LEFT seconds or more left -- whether a
# rule took it or not.  Written when the window ends, so the row carries both the
# readings at the touch and the result.  For hand-testing PRIME / GOLD rules.
#
# The candle readings (RSI, stoch, ROC ...) are NOT stored: they can be rebuilt
# exactly from the Binance candles.  The row keeps what can NOT be rebuilt:
#   s      seconds into the window at the touch          w0   seconds into the window when the bot first saw it (> 15 = joined late)
#   open   the side's ask at the first poll of the window age  age of the prices at the touch (s)
#   j      what PRIME / GOLD said at the touch: leg:rule | leg:rule:gate:<id> | leg:rule:accel | - (no rule) | na (a reading missing)
#   V      the Violent letters that were on (- = none)   chop 1 = CHOP release active
#   g      GRIND: BTC move bp / FLIP / steadiness        mv / bmv   the coin's and BTC's spot move since the window's first poll (bp)
#   mn     lowest ask from the touch until TOUCH_REC_LEFT seconds were left (a 25c bid FILLS when mn <= 0.24, or on prints at 0.25)
#   mx     highest bid of the side from the touch to the end (>= 0.98 / >= 0.85 = the exits were reachable)
#   last   own bid / other bid at the window's last poll;  status won = own > other there
# Display and research only: it places nothing and changes no decision.
# ==============================================================================
def _trec_judge(self, tf, cs, side, now) -> str:
    """What PRIME / GOLD say for this side now (the same order of checks as nl_check; nothing is logged or placed)."""
    try:
        for L in NL_LEGS_BY_TF[tf]:
            r = nl_match(self, L, cs, side, now)
            if r == "n/a":
                return "na"
            if r is not None:
                gt = nl_gate(self, L, cs, side, now)
                if gt is None and (L, r) in NL_TIGHT:
                    for _tk in NL_TIGHT[(L, r)]:
                        _w = _leg_nl_cond(self, _tk["when"], cs, side, now)
                        if _w is not None and _tk.get("unless") and _leg_nl_cond(self, _tk["unless"], cs, side, now) is not None:
                            _w = None
                        if _w is not None and _tk.get("unless_any") and _h8_unless_any(self, _tk["unless_any"], cs, side, now):
                            _w = None
                        if _w is not None:
                            gt = (_tk["id"], _w); break
                if gt is not None:
                    return "%s:%d:gate:%s" % (L, r + 1, str(gt[0]).replace(" ", "_"))
                if nl_accel(self, cs, side, now) is not None:
                    return "%s:%d:accel" % (L, r + 1)
                return "%s:%d" % (L, r + 1)
        return "-"
    except Exception:           # noqa: BLE001
        return "?"


def _trec_spot(self, cs):
    try:
        sp = getattr(self, "spot", None)
        if sp is None:
            return None
        v = sp.px.get(cs)
        if v is None:
            for full, sym in COINS.items():
                if sym == cs:
                    v = sp.px.get(full)
        return float(v) if v else None
    except Exception:           # noqa: BLE001
        return None


def _trec_state(self, P) -> str:
    """The filter states, read at most once every 5 s: Violent letters, CHOP, GRIND."""
    c = getattr(self, "_trec_fs", None)
    if c is not None and time.time() - c[0] < 5.0:
        return c[1]
    try:
        v = "".join(sorted(str(x) for x in (self._violent_letters() or ()))) or "-"
    except Exception:           # noqa: BLE001
        v = "?"
    try:
        ch = "1" if self._chop_active() else "0"
    except Exception:           # noqa: BLE001
        ch = "?"
    try:
        mv, fl, stdy = self.grind_state(P)
        g_ = "%s/%s/%s" % ("?" if mv is None else "%+.0f" % mv, "?" if fl is None else fl, "?" if stdy is None else "%.2f" % stdy)
    except Exception:           # noqa: BLE001
        g_ = "?"
    s = "V=%s chop=%s g=%s" % (v, ch, g_)
    self._trec_fs = (time.time(), s)
    return s


def _trec_flush(self, w, tf) -> None:
    for (cs, side), r in sorted(w["rows"].items()):
        try:
            u, d = w["last"].get(cs, (None, None))
            own, oth = (u, d) if side == UP else (d, u)
            res = "?" if own is None or oth is None else ("won" if own > oth else "lost")
            log_csv(ts=now_ts(), period_start=w["P"], coin=cs, src="rec5" if tf == 300 else "rec15", fade_dir=side,
                    limit=TOUCH_REC_PX, action="touch25", price=r["ask"], status=res,
                    note="%s | mn=%.2f mx=%.2f last=%s/%s" % (r["note"], r["mn"], r["mx"],
                                                             "-" if own is None else "%.2f" % own, "-" if oth is None else "%.2f" % oth))
        except Exception:       # noqa: BLE001
            pass


def touch_rec(self, snap, secs_left, tf, age=None) -> None:
    """THE 25c TOUCH RECORDER -- called on every poll for each clock.  Never raises, places nothing."""
    try:
        if not TOUCH_REC or not snap or secs_left is None:
            return
        P = self.period5 if tf == 300 else self.period
        st = self.__dict__.setdefault("_trec", {})
        w = st.get(tf)
        if w is None or w["P"] != P:
            if w is not None:
                _trec_flush(self, w, tf)
            w = st[tf] = {"P": P, "open": {}, "sp0": {}, "rows": {}, "last": {}, "w0": max(0, int(tf - secs_left))}
        for cs, p in snap.items():
            u, d = p.get(UP), p.get(DOWN)
            w["last"][cs] = (u, d)
            if cs not in w["sp0"]:
                w["sp0"][cs] = _trec_spot(self, cs)
            for side, own, opp in ((UP, u, d), (DOWN, d, u)):
                if opp is None:
                    continue
                ask = round(1.0 - float(opp), 2)
                k = (cs, side)
                w["open"].setdefault(k, ask)
                r = w["rows"].get(k)
                if r is not None:
                    if secs_left >= TOUCH_REC_LEFT:
                        r["mn"] = min(r["mn"], ask)
                    if own is not None:
                        r["mx"] = max(r["mx"], float(own))
                    continue
                if ask > TOUCH_REC_PX + 1e-9 or secs_left < TOUCH_REC_LEFT:
                    continue
                def _bp(c_):
                    a, b = w["sp0"].get(c_), _trec_spot(self, c_)
                    return "?" if not a or not b else "%+.1f" % ((b / a - 1.0) * 1e4)
                if "BTC" not in w["sp0"]:
                    w["sp0"]["BTC"] = _trec_spot(self, "BTC")
                note = "s=%d w0=%d open=%.2f age=%s j=%s %s mv=%s bmv=%s" % (
                    int(tf - secs_left), w["w0"], w["open"][k], "?" if age is None else "%.1f" % age,
                    _trec_judge(self, tf, cs, side, int(now_ts())), _trec_state(self, P), _bp(cs), _bp("BTC"))
                w["rows"][k] = {"ask": ask, "note": note, "mn": ask, "mx": float(own) if own is not None else 0.0}
    except Exception:           # noqa: BLE001
        pass


'''

# ------------------------------------------------------------------ edit 3: the recorder's hook (inside nl_check, after the freshness guard)
A3 = '        _sat = "" if _sa is None else " [snap %.1f s]" % _sa\n'
N3 = A3 + '        touch_rec(self, snap, secs_left, tf, _sa)                     # the 25c touch recorder (rows only; places nothing) -- see TOUCH_REC\n'


def once(s, a, what):
    if s.count(a) != 1:
        sys.exit("STOP: anchor for %s found %d times (need exactly 1). Nothing written." % (what, s.count(a)))
    return s.find(a)


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else (src[:-3] if src.endswith(".py") else src) + ".rec.py"
    s = open(src, encoding="utf-8").read()
    if "TOUCH_REC" in s:
        sys.exit("STOP: this file already has the recorder patch. Nothing written.")
    for need in ("PAPER_ASK_THROUGH", "NL_ARM_FROM_OPEN", "NL_FRESH_MAX", "SETTLE_REAL"):
        if need not in s:
            sys.exit("STOP: %r not in the file -- run this on v9.03i-11 AFTER paper_ask_apply.py. Nothing written." % need)
    once(s, A1, "edit 1 (settings)"); once(s, A3, "edit 3 (hook)")
    i, j = once(s, S2, "edit 2 (start)"), once(s, E2, "edit 2 (end)")
    if not i < j:
        sys.exit("STOP: edit 2: end marker is above the start. Nothing written.")
    got = hashlib.sha1(s[i:j].encode("utf-8")).hexdigest()[:8]
    if got != H2:
        sys.exit("STOP: edit 2: loop_log_end is not the v9.03i-11 one (hash %s, expected %s). Nothing written." % (got, H2))
    s = s[:i] + N2 + s[j:]
    s = s.replace(A1, N1, 1).replace(A3, N3, 1)
    if "open(LOOP_FILE" in s:
        sys.exit("STOP: gateloop.csv is still written. Nothing written.")
    compile(s, dst, "exec")
    open(dst, "w", encoding="utf-8", newline="\n").write(s)
    print("ok: 3 edits ->", dst)


if __name__ == "__main__":
    main()
