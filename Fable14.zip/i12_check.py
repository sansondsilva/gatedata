#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
i12_check.py  --  check the next logs of v9.03i-12   (Fable, 17 Nov)

    python i12_check.py                       (in the folder with the four gate files)
    python i12_check.py --dir C:\\path\\to\\logs
    python i12_check.py --ledger gatetrades.csv --ticks5m gateticks5m.csv --ticks15m gateticks.csv

Prints OK / CHECK for:
  1. LOOP STATS       a loop_stats row for every 5 minutes the bot ran
  2. gateloop.csv     gone, or no longer growing
  3. TOUCH RECORDER   a touch25 row for every 25c first touch in the tick files (5m and 15m), none extra,
                      every row with its readings and a result, and the result agreeing with the tick files
  4. PAPER FILLS      paper_ask_fill rows present (the ask-below-the-bid rule is live)
Times are UTC.
"""
import argparse, csv, gzip, os, sys
from collections import defaultdict
from datetime import datetime, timezone

COINS = ("btc", "eth", "sol", "xrp")
KEYS = ("s", "w0", "open", "age", "j", "V", "chop", "g", "mv", "bmv", "mn", "mx", "last")


def rd(fn):
    op = gzip.open if fn.endswith(".gz") else open
    with op(fn, "rt", encoding="utf-8", errors="replace", newline="") as f:
        return list(csv.DictReader(f))


def fnum(x):
    try:
        v = float(x)
        return v if v == v else None
    except Exception:
        return None


def hm(t):
    return datetime.fromtimestamp(t, timezone.utc).strftime("%d %b %H:%M")


def say(ok, text):
    print("  [%s] %s" % ("OK   " if ok else "CHECK", text))
    return ok


def tick_touches(fn, tf, px=0.25, left=60):
    """(P, COIN, side) -> (touch ts, side ahead at the last tick, first-seen seconds) for windows seen from the start to the end."""
    wins = defaultdict(list)
    for r in rd(fn):
        ts, P = fnum(r.get("ts")), fnum(r.get("period_start"))
        if ts is None or P is None:
            continue
        wins[int(P)].append((int(ts), {k: fnum(r.get(k)) for c in COINS for k in (c + "_up", c + "_dn")}))
    out, seen = {}, {}
    for P, tk in wins.items():
        tk.sort(key=lambda x: x[0])
        w0, w1 = tk[0][0] - P, tk[-1][0] - P
        seen[P] = (w0, w1)
        for c in COINS:
            for side, own, opp in (("UP", c + "_up", c + "_dn"), ("DOWN", c + "_dn", c + "_up")):
                last = tk[-1][1]
                for t, p in tk:
                    if p.get(opp) is None or t > P + tf - left:
                        continue
                    if 1.0 - p[opp] <= px + 1e-9:
                        won = None if last.get(own) is None or last.get(opp) is None else last[own] > last[opp]
                        out[(P, c.upper(), side)] = (t, won, w0)
                        break
    return out, seen


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir", default=".")
    ap.add_argument("--ledger"); ap.add_argument("--ticks5m"); ap.add_argument("--ticks15m")
    ap.add_argument("--list", action="store_true", help="list the missing / extra recorder rows")
    a = ap.parse_args()
    J = lambda n: os.path.join(a.dir, n)
    led = a.ledger or J("gatetrades.csv"); t5 = a.ticks5m or J("gateticks5m.csv"); t15 = a.ticks15m or J("gateticks.csv")
    rows = [r for r in rd(led) if fnum(r.get("ts")) is not None]
    for r in rows:
        r["_ts"] = int(float(r["ts"]))
    bad = 0

    # ---- 1. loop stats
    print("1. LOOP STATS")
    ls = [r for r in rows if r.get("action") == "loop_stats"]
    if not ls:
        bad += not say(False, "no loop_stats rows in %s" % led)
        t_first = None
    else:
        t_first, t_last = ls[0]["_ts"], ls[-1]["_ts"]
        want = max(1, (t_last - t_first) // 300 + 1)
        b = sorted({int(float(r["period_start"])) for r in ls if fnum(r.get("period_start")) is not None})
        gaps = [(x, y) for x, y in zip(b, b[1:]) if y - x > 300]
        bad += not say(len(ls) >= 0.97 * want, "%d rows, %s -> %s (one per 5 minutes would be %d)" % (len(ls), hm(t_first), hm(t_last), want))
        say(not gaps, "%d gap(s) between rows%s" % (len(gaps), "" if not gaps else ": " + ", ".join("%s (%d min)" % (hm(x), (y - x) // 60) for x, y in gaps[:6])
                                                   + "  -- a gap is normal where the bot was stopped"))
        need = ("polls=", "ge4=", "ge5=", "max=", "before=", "prices=", "after=", "kl=", "http=", "fresh=")
        okn = sum(1 for r in ls if all(k in (r.get("note") or "") for k in need))
        bad += not say(okn == len(ls), "%d of %d rows carry every field" % (okn, len(ls)))

    # ---- 2. gateloop.csv
    print("2. gateloop.csv")
    gl = J("gateloop.csv")
    if not os.path.exists(gl):
        say(True, "not in the folder")
    else:
        try:
            last = max(int(float(r["ts"])) for r in rd(gl) if fnum(r.get("ts")) is not None)
        except Exception:
            last = None
        grow = last is not None and t_first is not None and last > t_first
        bad += not say(not grow, "still in the folder; its last row is %s%s" % (hm(last) if last else "?", " -- AFTER the first loop_stats row: it is still being written" if grow
                                                                                    else " (before the new build: an old file, safe to delete)"))

    # ---- 3. recorder
    print("3. THE 25c TOUCH RECORDER")
    rec = [r for r in rows if r.get("action") == "touch25"]
    if not rec:
        bad += not say(False, "no touch25 rows")
    else:
        r0 = min(r["_ts"] for r in rec); r1 = max(r["_ts"] for r in rec)
        days = max((r1 - r0) / 86400.0, 1e-9)
        size = sum(len(",".join(str(v) for k, v in r.items() if k != "_ts")) + 2 for r in rec) / 1e6
        print("  rows %d  (5m %d, 15m %d)   %.0f a day   %.2f MB a day" % (len(rec), sum(1 for r in rec if r.get("src") == "rec5"),
                                                                           sum(1 for r in rec if r.get("src") == "rec15"), len(rec) / days, size / days))
        full = sum(1 for r in rec if all((" " + k + "=") in (" " + (r.get("note") or "")) for k in KEYS))
        bad += not say(full == len(rec), "%d of %d rows carry every reading" % (full, len(rec)))
        res = defaultdict(int)
        for r in rec:
            res[r.get("status") or ""] += 1
        unk = len(rec) - res["won"] - res["lost"]
        bad += not say(unk <= 0.01 * len(rec), "results: won %d, lost %d, no result %d" % (res["won"], res["lost"], unk))
        jn = defaultdict(int)
        for r in rec:
            j = [w[2:] for w in (r.get("note") or "").split() if w.startswith("j=")]
            j = j[0] if j else "?"
            jn["no rule" if j == "-" else ("reading missing" if j in ("na", "?") else ("rule, gated" if (":gate:" in j or j.endswith(":accel")) else "rule taken"))] += 1
        print("  what PRIME / GOLD said at the touch: " + ", ".join("%s %d" % kv for kv in sorted(jn.items(), key=lambda kv: -kv[1])))
        for tf, fn, src in ((300, t5, "rec5"), (900, t15, "rec15")):
            if not os.path.exists(fn):
                say(False, "%s not found: the %dm rows were not compared with the ticks" % (fn, tf // 60)); continue
            tt, seen = tick_touches(fn, tf)
            mine = {(int(float(r["period_start"])), r.get("coin"), r.get("fade_dir")): r for r in rec if r.get("src") == src and fnum(r.get("period_start")) is not None}
            Ps = {k[0] for k in mine}
            if not Ps:
                bad += not say(False, "%dm: no rows" % (tf // 60)); continue
            lo, hi = min(Ps), max(Ps)
            # windows the bot ran from start to end, inside the recorder's span
            okP = {P for P, (w0, w1) in seen.items() if lo <= P <= hi and w0 <= 30 and w1 >= tf - 15}
            exp = {k for k in tt if k[0] in okP}
            got = {k for k in mine if k[0] in okP}
            miss, extra = exp - got, got - exp
            # a touch within a poll or two of the 60 s line can fall either side of it
            edge = lambda k: k in tt and tt[k][0] >= k[0] + tf - 60 - 12
            miss_r = [k for k in miss if not edge(k)]
            agree = sum(1 for k in exp & got if tt[k][1] is not None and (mine[k].get("status") == "won") == tt[k][1])
            both = sum(1 for k in exp & got if tt[k][1] is not None)
            bad += not say(len(miss_r) <= 0.02 * max(1, len(exp)) and len(extra) <= 0.03 * max(1, len(exp)),
                           "%dm: %d touches in the ticks, %d recorded;  missing %d (%d at the 60 s line),  extra %d"
                           % (tf // 60, len(exp), len(exp & got), len(miss), len(miss) - len(miss_r), len(extra)))
            bad += not say(both == 0 or agree >= 0.97 * both, "%dm: result agrees with the ticks on %d of %d" % (tf // 60, agree, both))
            if a.list:
                for nm, ks in (("missing", sorted(miss)), ("extra", sorted(extra))):
                    for k in ks[:40]:
                        print("      %s  %s  %s %s" % (nm, hm(k[0]), k[1], k[2]))

    # ---- 4. paper fills
    print("4. PAPER FILLS")
    af = sum(1 for r in rows if r.get("action") == "paper_ask_fill")
    fl = sum(1 for r in rows if r.get("action") == "fill")
    dry = any(str(r.get("order_id", "")).startswith("DRY") for r in rows if r.get("action") == "place_buy")
    if not dry:
        say(True, "no paper orders in this ledger (live): nothing to check")
    else:
        bad += not say(af > 0, "paper_ask_fill rows: %d   (all fills: %d)" % (af, fl))
    print()
    print("ALL OK" if not bad else "%d item(s) to look at" % bad)


if __name__ == "__main__":
    main()
