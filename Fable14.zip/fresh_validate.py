#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fresh_validate.py  --  did the freshness patch work?   (Fable, 15 Nov)

    python fresh_validate.py --a gatetrades.csv --ticks-a gateticks5m.csv
    python fresh_validate.py --a gatetrades.csv --ticks-a gateticks5m.csv \
                             --b B-gatetrades.csv --ticks-b B-gateticks5m.csv \
                             --since "2026-11-14 16:00" --until "2026-11-15 02:10"

Prints (times are UTC):
  1. THE LOOP     how long the polls take (from the 5m tick file), and the first 15 s of each 5m window on its own
  2. PRICE AGE    how old the snapshot was when a PRIME / GOLD order was placed
                  (the "[snap x s]" stamp on new builds; estimated from the tick file on old builds)
  3. A vs B       the same order on both laptops / on one only, per leg
  4. GUARD ROWS   snap_refresh, nl_stale_skip, paper re-prices, first-touch skips
  5. LOOP STATS   where the polls' time went (the loop_stats rows in the ledger)
Targets after the patch: price age over 3 s = about 0%; loops of 5 s or more well under the old 27%.
"""
import argparse, bisect, csv, gzip, re, sys
from collections import defaultdict
from datetime import datetime, timezone

LEGS = ("prime5", "gold5", "prime15", "gold15")


def rd(fn):
    op = gzip.open if fn.endswith(".gz") else open
    with op(fn, "rt", encoding="utf-8", errors="replace", newline="") as f:
        return list(csv.DictReader(f))


def fnum(x):
    try:
        return float(x)
    except Exception:
        return None


def to_ts(s):
    if not s:
        return None
    if s.isdigit():
        return int(s)
    for fm in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return int(datetime.strptime(s, fm).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            pass
    sys.exit("bad time: " + s)


def hm(ts):
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%d %b %H:%M:%S")


def pct(a, b):
    return "%5.1f%%" % (100.0 * a / b) if b else "    - "


def ticks_ts(fn, lo, hi):
    v = sorted({int(float(r["ts"])) for r in rd(fn) if fnum(r.get("ts")) is not None})
    return [t for t in v if (lo is None or t >= lo) and (hi is None or t < hi)]


def loop_report(name, ts):
    gaps = [(a, b - a) for a, b in zip(ts, ts[1:]) if b - a < 120]
    if not gaps:
        print("  %s: no ticks" % name); return
    g = sorted(x for _, x in gaps); n = len(g)
    op = [x for a, x in gaps if a % 300 < 15]; rest = [x for a, x in gaps if a % 300 >= 15]
    print("  %-2s polls %6d   median %.0f s   5 s+ %s   8 s+ %5d   15 s+ %4d   longest %.0f s"
          % (name, n, g[n // 2], pct(sum(1 for x in g if x >= 5), n), sum(1 for x in g if x >= 8), sum(1 for x in g if x >= 15), g[-1]))
    if op:
        print("     first 15 s of a 5m window: %4d polls, average %.1f s, 8 s+ %s      rest of the window: average %.1f s, 5 s+ %s"
              % (len(op), sum(op) / len(op), pct(sum(1 for x in op if x >= 8), len(op)), sum(rest) / max(1, len(rest)), pct(sum(1 for x in rest if x >= 5), len(rest))))


def orders(rows, lo, hi):
    out = {}
    for r in rows:
        if r.get("action") != "place_buy" or r.get("src") not in LEGS:
            continue
        ts, P = fnum(r.get("ts")), fnum(r.get("period_start"))
        if ts is None or P is None or (lo and ts < lo) or (hi and ts >= hi):
            continue
        note = r.get("note") or ""
        m = re.search(r"\[snap ([0-9.]+) s\]", note)
        k = (int(P), r.get("coin"), r["src"], r.get("fade_dir"))
        out.setdefault(k, {"ts": int(ts), "snap": float(m.group(1)) if m else None, "note": note,
                           "how": "pre-armed" if "PRE-ARMED" in note else ("first touch" if "FIRST TOUCH" in note else "?")})
    return out


def filled(rows):
    return {(int(float(r["period_start"])), r.get("coin"), r.get("src"), r.get("fade_dir"))
            for r in rows if r.get("action") == "fill" and r.get("src") in LEGS and fnum(r.get("period_start")) is not None}


def age_report(name, od, tks):
    stamped = [o["snap"] for o in od.values() if o["snap"] is not None]
    if stamped:
        n = len(stamped)
        print("  %-2s PRIME / GOLD orders with the stamp: %d   age over 3 s: %d (%s)   oldest %.1f s   average %.1f s"
              % (name, n, sum(1 for x in stamped if x > 3), pct(sum(1 for x in stamped if x > 3), n).strip(), max(stamped), sum(stamped) / n))
    rest = [o for o in od.values() if o["snap"] is None]
    if rest and tks:
        est = []
        for o in rest:
            i = bisect.bisect_right(tks, o["ts"]) - 1
            if i >= 0 and o["ts"] - tks[i] < 120:
                est.append(o["ts"] - tks[i])
        if est:
            n = len(est)
            print("  %-2s orders WITHOUT the stamp (old build): %d   estimated age (order time - its poll's start)   4 s+: %d (%s)   6 s+: %d   oldest %d s"
                  % (name, n, sum(1 for x in est if x >= 4), pct(sum(1 for x in est if x >= 4), n).strip(), sum(1 for x in est if x >= 6), max(est)))
    if not stamped and not rest:
        print("  %-2s no PRIME / GOLD orders" % name)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--a", required=True, help="laptop A ledger (gatetrades.csv)")
    ap.add_argument("--b", help="laptop B ledger")
    ap.add_argument("--ticks-a"); ap.add_argument("--ticks-b")
    ap.add_argument("--loop", help="(old builds only; ignored)")
    ap.add_argument("--since"); ap.add_argument("--until")
    ap.add_argument("--list", action="store_true", help="list the orders placed on one laptop only")
    a = ap.parse_args()
    lo, hi = to_ts(a.since), to_ts(a.until)
    A = rd(a.a); B = rd(a.b) if a.b else None
    if B is not None and lo is None and hi is None:              # both laptops: only the time both were running
        ra = [fnum(r.get("ts")) for r in A if fnum(r.get("ts"))]; rb = [fnum(r.get("ts")) for r in B if fnum(r.get("ts"))]
        lo, hi = int(max(min(ra), min(rb))), int(min(max(ra), max(rb))) + 1
    print("window: %s -> %s UTC" % (hm(lo) if lo else "start", hm(hi) if hi else "end"))

    ta = ticks_ts(a.ticks_a, lo, hi) if a.ticks_a else []
    tb = ticks_ts(a.ticks_b, lo, hi) if a.ticks_b else []
    print("\n1. THE LOOP")
    if ta:
        loop_report("A", ta)
    if tb:
        loop_report("B", tb)
    if not ta and not tb:
        print("  (give --ticks-a / --ticks-b)")

    oa = orders(A, lo, hi); ob = orders(B, lo, hi) if B is not None else None
    print("\n2. PRICE AGE WHEN A PRIME / GOLD ORDER WAS PLACED")
    age_report("A", oa, ta)
    if ob is not None:
        age_report("B", ob, tb)

    if ob is not None:
        fa, fb = filled(A), filled(B)
        print("\n3. A vs B   (same window, same coin, same leg, same side)")
        print("  leg        both   A only   B only   agree     one-laptop orders that FILLED")
        tot = [0, 0, 0]
        for leg in LEGS:
            ka = {k for k in oa if k[2] == leg}; kb = {k for k in ob if k[2] == leg}
            both, ao, bo = len(ka & kb), len(ka - kb), len(kb - ka)
            tot[0] += both; tot[1] += ao; tot[2] += bo
            fl = sum(1 for k in (ka - kb) if k in fa) + sum(1 for k in (kb - ka) if k in fb)
            print("  %-9s %5d   %6d   %6d   %s   %d" % (leg, both, ao, bo, pct(both, both + ao + bo), fl))
        print("  %-9s %5d   %6d   %6d   %s" % ("all", tot[0], tot[1], tot[2], pct(tot[0], sum(tot))))
        if a.list:
            for who, o1, o2 in (("A only", oa, ob), ("B only", ob, oa)):
                for k in sorted(set(o1) - set(o2)):
                    o = o1[k]
                    print("    %s  %s  %s %-7s %-4s  %-11s  snap %s" % (who, hm(o["ts"]), k[1], k[2], k[3], o["how"], "-" if o["snap"] is None else "%.1f s" % o["snap"]))

    print("\n4. GUARD ROWS")
    for name, rows in (("A", A), ("B", B)):
        if rows is None:
            continue
        c = defaultdict(int)
        for r in rows:
            ts = fnum(r.get("ts"))
            if ts is None or (lo and ts < lo) or (hi and ts >= hi):
                continue
            act = r.get("action")
            if act in ("snap_refresh", "nl_stale_skip", "nl_first_touch_skip"):
                c[act] += 1
            elif act == "reprice":
                c["reprice (paper)" if str(r.get("status", "")).startswith("paper") else "reprice (live)"] += 1
        print("  %-2s " % name + ("   ".join("%s %d" % kv for kv in sorted(c.items())) or "none"))

    print("\n5. LOOP STATS   (the loop_stats rows in the ledger, one per 5 minutes)")
    for name, rows in (("A", A), ("B", B)):
        if rows is None:
            continue
        L = []
        for r in rows:
            ts = fnum(r.get("ts"))
            if r.get("action") != "loop_stats" or ts is None or (lo and ts < lo) or (hi and ts >= hi):
                continue
            d = {}
            for w in (r.get("note") or "").split():
                if "=" in w:
                    k, v = w.split("=", 1)
                    if "/" in v:
                        x, y = v.split("/", 1)
                        d[k + "_n"], d[k + "_s"] = fnum(x) or 0.0, fnum(y) or 0.0
                    else:
                        d[k] = fnum(v) or 0.0
            if d.get("polls"):
                L.append(d)
        if not L:
            print("  %-2s no loop_stats rows (old build, or LOOP_LOG off)" % name)
            continue
        S = lambda k: sum(d.get(k, 0.0) for d in L)
        n = S("polls")
        print("  %-2s rows %d   polls %d   4 s+ %s   5 s+ %s   slowest %.1f s   slowest in the first 15 s of a window: average %.1f s"
              % (name, len(L), n, pct(S("ge4"), n).strip(), pct(S("ge5"), n).strip(), max(d.get("max", 0.0) for d in L),
                 sum(d.get("open_max", 0.0) for d in L) / len(L)))
        tot = S("total") or 1e-9
        print("     seconds per poll: %.2f   = before prices %.2f + prices %.2f + after %.2f"
              % (tot / n, S("before") / n, S("prices") / n, S("after") / n))
        print("     of which candle requests %.2f s (%.1f per poll, %.2f s each)   other http %.2f s (%.1f per poll)   re-reads %d (%.2f s each)"
              % (S("kl_s") / n, S("kl_n") / n, S("kl_s") / max(1.0, S("kl_n")), S("http_s") / n, S("http_n") / n,
                 S("fresh_n"), S("fresh_s") / max(1.0, S("fresh_n"))))
    if a.loop:
        print("  (--loop is no longer needed: gateloop.csv was replaced by the loop_stats rows)")

if __name__ == "__main__":
    main()
