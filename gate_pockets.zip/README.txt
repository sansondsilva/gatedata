GATE POCKETS -- profit / risk pockets, top-down like FLAT (3 Nov 2026, for v9.02d-10)
=====================================================================================
Input: pockets_population.csv = 6,114 RAW standard-leg trades (no Violent / LEG / breaker filters) with result, 'kept' by v9.02d-10, entry, and the
highest bid reached after the fill (real price paths). Candles: recent_1m\ (to 3 Nov 03:32). Indicators: the rule hunter's 1m / 5m / 15m / 1h + 4h.

1. 4-HOUR REGIMES first (singles, pairs, triples), then DRILL DOWN inside each with 1h / 15m / 5m / 1m conditions (pairs of different timeframes).
2. STRONG pockets: raw trades better than the raw baseline in history AND replay AND live (avg >= baseline + margin, win >= +6 pts), +-10% stable
   -> the bot's OWN trades inside: what 1.5x / 2x shares would add, and the worst day.
3. WEAK pockets: raw trades worse and losing in every period -> the bot's own trades inside: SKIP vs a 69c EXIT (real paths), the better one.
4. NEUTRAL: the bot's own trades in no strong / weak pocket -> a 75c take-profit vs the normal exit (85c BIRD, 98c others), overall and per leg.
5. WALK-FORWARD: regimes picked on trades before 15 Oct only, checked after.

SETUP: unzip INTO C:\tmp -> gate_pockets.py, rule_hunter.py, pockets_population.csv, recent_1m\
RUN (from C:\tmp):           aitv\Scripts\python gate_pockets.py
   deeper (overnight):       aitv\Scripts\python gate_pockets.py --step 0.05 --triples 1000 --regimes 12 --drills 4
   milder weak pockets:      add --weak-margin 0.25
SEND BACK: zip gate_pockets_out\ (summary.txt first, strong.csv, weak.csv, neutral.csv, walkforward.csv) -> GitHub. Nothing is built until you say so.
