"""rule_hunter.py -- hunt for VR + ER + ?? rules.

Run:   python rule_hunter.py                      (defaults below)
       python rule_hunter.py --vr 1.1 --er 0.45 --live all --min-hist 15 --min-replay 5 --min-live 5 --top 30
Needs: Python 3 with pandas and numpy  (pip install pandas numpy)
Files: bets.csv and btc_1m.csv.gz in the same folder.
Output: hunt_results.csv (every rule that passed, best first) and a short list on screen.

What it does
  1. takes the bets with BTC 1-minute VR > --vr and ER12 >= --er (the sharp-burst bets);
  2. history and replay use only the bets the current bot still takes (kept = True), so a rule found here is NEW on top of it;
     live uses --live all (every live trade, default) or --live kept;
  3. computes ~80 indicators on BTC candles CLOSED by each bet's window start, turned to the BET'S side
     (oscillators: low = stretched against the bet; signed values: + = with the bet);
  4. tests every single condition (indicator <= or >= a threshold at the 10%-90% points) and every PAIR of conditions;
  5. keeps a rule only if the held bets save money in EVERY set (history, replay, live), each set has at least the minimum held bets,
     the held bets are mostly losers (--min-losers), and the neighbouring thresholds also pass (not a lucky line).
"""
import argparse, time, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")

def args():
    a = argparse.ArgumentParser()
    a.add_argument("--vr", type=float, default=1.1); a.add_argument("--er", type=float, default=0.45)
    a.add_argument("--live", default="all", choices=["all", "kept"])
    a.add_argument("--group", default="burst", choices=["burst", "calm", "all", "slide"])   # burst = VR+ER bets; calm = the others; all = every bet;
                                                                                          # slide = 4h OsMA(3,10,16) against the bet >= --slide-run bars, minus G1's holds
    a.add_argument("--slide-run", type=int, default=9)
    a.add_argument("--min-hist", type=int, default=15); a.add_argument("--min-replay", type=int, default=5); a.add_argument("--min-live", type=int, default=5)
    a.add_argument("--min-losers", type=float, default=0.65); a.add_argument("--top", type=int, default=30); a.add_argument("--no-pairs", action="store_true")
    return a.parse_args()

# ------------------------------------------------------------------ indicators (pandas, on one timeframe)
def wrsi(c, n):
    d = np.diff(c, prepend=np.nan); up = np.clip(np.nan_to_num(d), 0, None); dn = np.clip(-np.nan_to_num(d), 0, None)
    au = pd.Series(up).ewm(alpha=1 / n, adjust=False).mean().values; ad = pd.Series(dn).ewm(alpha=1 / n, adjust=False).mean().values
    return np.where(ad == 0, 100.0, 100 - 100 / (1 + au / np.where(ad == 0, 1, ad)))

def tf_features(g):
    """g: candles of one timeframe (o h l c v tb). Returns a dict of raw series (not yet bet-oriented) and their kind."""
    o, h, l, c, v = g.o, g.h, g.l, g.c, g.v.where(g.v > 0)
    F = {}
    for n in (3, 7, 14): F["rsi%d" % n] = (wrsi(c.values, n), "osc")
    tp = (h + l + c) / 3
    for n in (14, 20):
        md = tp.rolling(n).apply(lambda x: np.mean(np.abs(x - x.mean())), raw=True); F["cci%d" % n] = (((tp - tp.rolling(n).mean()) / (0.015 * md)).values, "sgn")
    m = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean(); os_ = m - m.ewm(span=9, adjust=False).mean()
    F["osma_bp"] = ((os_ / c * 1e4).values, "sgn")
    sg = np.sign(os_.values); run = np.ones(len(sg))
    for i in range(1, len(sg)): run[i] = run[i - 1] + 1 if (sg[i] == sg[i - 1] and sg[i] != 0) else 1
    F["osma_run"] = (sg * run, "sgn")                                            # + = OsMA on the bet's side for N bars
    tr = np.maximum(h - l, np.maximum((h - c.shift()).abs(), (l - c.shift()).abs())); w = lambda x: x.ewm(alpha=1 / 14, adjust=False).mean()
    atr = w(tr); up = h - h.shift(); dn = l.shift() - l
    pdi = 100 * w(pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=g.index)) / atr; ndi = 100 * w(pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=g.index)) / atr
    F["adx"] = (w(100 * (pdi - ndi).abs() / (pdi + ndi).replace(0, np.nan)).values, "abs"); F["di"] = ((pdi - ndi).values, "sgn")
    sma = c.rolling(20).mean(); sd = c.rolling(20).std(ddof=0)
    F["bb_pos"] = (((c - (sma - 2 * sd)) / (4 * sd)).values * 100, "osc")
    bw = 4 * sd / sma; F["bbw_ratio"] = ((bw / bw.rolling(24, min_periods=12).median()).values, "abs")
    F["stoch14"] = ((100 * (c - l.rolling(14).min()) / (h.rolling(14).max() - l.rolling(14).min())).values, "osc")
    F["er12"] = (((c - c.shift(12)).abs() / c.diff().abs().rolling(12).sum()).values, "abs")
    col = np.sign((c - o).values); F["flip12"] = (pd.Series(np.r_[np.nan, (col[1:] != col[:-1]).astype(float)]).rolling(11).sum().values, "abs")
    for n in (20, 50): F["ema%d_gap" % n] = (((c / c.ewm(span=n, adjust=False).mean() - 1) * 1e4).values, "sgn")
    F["ret12"] = (((c / c.shift(12) - 1) * 1e4).values, "sgn")
    F["atr_ratio"] = ((atr / atr.rolling(50, min_periods=25).median()).values, "abs")
    mf = tp * v; pos = mf.where(tp > tp.shift(), 0).rolling(14).sum(); neg = mf.where(tp < tp.shift(), 0).rolling(14).sum()
    F["mfi14"] = ((100 - 100 / (1 + pos / neg)).values, "osc")
    mfv = (((c - l) - (h - c)) / (h - l).replace(0, np.nan)) * v
    F["cmf20"] = ((mfv.rolling(20).sum() / v.rolling(20).sum()).values, "sgn")
    # ---- enhanced set (final run, 1 Nov)
    F["willr14"] = ((100 * (c - l.rolling(14).min()) / (h.rolling(14).max() - l.rolling(14).min())).values, "osc")     # Williams %R as 0-100
    F["macd_hist_bp"] = (((m - m.ewm(span=9, adjust=False).mean()) / c * 1e4).values, "sgn")
    for n in (5, 10): F["roc%d" % n] = (((c / c.shift(n) - 1) * 1e4).values, "sgn")
    dd = c.diff(); F["cmo14"] = ((100 * (dd.clip(lower=0).rolling(14).sum() - (-dd.clip(upper=0)).rolling(14).sum()) / dd.abs().rolling(14).sum()).values, "sgn")
    e1 = c.ewm(span=15, adjust=False).mean(); e3 = e1.ewm(span=15, adjust=False).mean().ewm(span=15, adjust=False).mean(); F["trix15"] = ((e3.pct_change() * 1e4).values, "sgn")
    au = h.rolling(26).apply(lambda x: (len(x) - 1 - np.argmax(x)), raw=True); ad_ = l.rolling(26).apply(lambda x: (len(x) - 1 - np.argmin(x)), raw=True)
    F["aroon_osc"] = ((((25 - au) - (25 - ad_)) / 25 * 100).values, "sgn")
    hl2 = (h + l) / 2; ub = (hl2 + 3 * atr).values; lb = (hl2 - 3 * atr).values; cc = c.values; st = np.zeros(len(cc)); fu = lb.copy(); fd = ub.copy()
    for i in range(1, len(cc)):
        fu[i] = max(lb[i], fu[i - 1]) if cc[i - 1] > fu[i - 1] else lb[i]; fd[i] = min(ub[i], fd[i - 1]) if cc[i - 1] < fd[i - 1] else ub[i]
        st[i] = 1 if cc[i] > fd[i - 1] else (-1 if cc[i] < fu[i - 1] else st[i - 1])
    F["supertrend"] = (st, "sgn")
    wma = lambda x, n: x.rolling(n).apply(lambda y: np.dot(y, np.arange(1, n + 1)) / (n * (n + 1) / 2), raw=True)
    hull = wma(2 * wma(c, 10) - wma(c, 20), 4); F["hull_slope_bp"] = (((hull / hull.shift(2) - 1) * 1e4).values, "sgn")
    F["donchian_pos"] = ((100 * (c - l.rolling(20).min()) / (h.rolling(20).max() - l.rolling(20).min())).values, "osc")
    kc_mid = c.ewm(span=20, adjust=False).mean(); kc_w = 2 * atr; F["keltner_pos"] = ((100 * (c - (kc_mid - kc_w)) / (2 * kc_w)).values, "osc")
    sq = ((sma + 2 * sd) < (kc_mid + 1.5 * atr)) & ((sma - 2 * sd) > (kc_mid - 1.5 * atr))
    F["squeeze_on"] = (sq.astype(float).values, "abs"); F["squeeze_release3"] = (((~sq) & sq.shift(1).fillna(False).rolling(3).max().astype(bool)).astype(float).values, "abs")
    hh10 = h.rolling(10).max(); ll10 = l.rolling(10).min(); x = (2 * ((hl2 - ll10) / (hh10 - ll10).replace(0, np.nan) - 0.5)).clip(-0.999, 0.999).ewm(alpha=0.33, adjust=False).mean().clip(-0.999, 0.999)
    F["fisher10"] = ((0.5 * np.log((1 + x) / (1 - x))).values, "sgn")
    bp = c - np.minimum(l, c.shift()); trr = np.maximum(h, c.shift()) - np.minimum(l, c.shift())
    F["ultosc"] = ((100 * (4 * bp.rolling(7).sum() / trr.rolling(7).sum() + 2 * bp.rolling(14).sum() / trr.rolling(14).sum() + bp.rolling(28).sum() / trr.rolling(28).sum()) / 7).values, "osc")
    F["chop14"] = ((100 * np.log10(tr.rolling(14).sum() / (h.rolling(14).max() - l.rolling(14).min())) / np.log10(14)).values, "abs")
    ha_c = (o + h + l + c) / 4; ha_o = ha_c.copy()
    hcv = np.array(ha_c.values, dtype=float); ov = np.array(o.values, dtype=float); cv2 = np.array(c.values, dtype=float); hv = hcv.copy()
    hv[0] = (ov[0] + cv2[0]) / 2
    for i in range(1, len(hv)): hv[i] = (hv[i - 1] + hcv[i - 1]) / 2
    hsg = np.sign(hcv - hv); hrun = np.ones(len(hsg))
    for i in range(1, len(hsg)): hrun[i] = hrun[i - 1] + 1 if (hsg[i] == hsg[i - 1] and hsg[i] != 0) else 1
    F["ha_streak"] = (hsg * hrun, "sgn")
    fi = (c.diff() * v).ewm(span=13, adjust=False).mean(); F["force_z"] = ((fi / fi.abs().rolling(100, min_periods=30).mean()).values, "sgn")
    obv = (np.sign(c.diff()) * v).fillna(0).cumsum(); F["obv_slope12"] = (((obv - obv.shift(12)) / v.rolling(12).sum()).values, "sgn")
    F["ichimoku_gap_bp"] = ((((h.rolling(9).max() + l.rolling(9).min()) / 2 - (h.rolling(26).max() + l.rolling(26).min()) / 2) / c * 1e4).values, "sgn")
    return F

def build(bets, C):
    t = C.t.values
    out = {}
    for tf, step in (("1m", 60), ("5m", 300), ("15m", 900), ("1h", 3600)):
        g = C.assign(g=C.t // step * step).groupby("g").agg(o=("open", "first"), h=("high", "max"), l=("low", "min"), c=("close", "last"), v=("volume", "sum"), n=("close", "size"))
        g = g[g.n >= step // 60]; te = g.index.values + step
        j = np.searchsorted(te, bets.P.values, side="right") - 1; ok = j >= 0; j = np.clip(j, 0, None); d = bets.d.values
        for k, (arr, kind) in tf_features(g).items():
            v = np.where(ok, arr[j], np.nan)
            out["%s_%s" % (k, tf)] = np.where(d > 0, v, 100 - v) if kind == "osc" else (v * d if kind == "sgn" else v)
    k = np.searchsorted(t + 60, bets.P.values, side="right") - 1; d = bets.d.values
    tp = ((C.high + C.low + C.close) / 3).values; vol = C.volume.fillna(0).values; day = t // 86400
    pv = pd.Series(tp * vol).groupby(day).cumsum().values; vv = pd.Series(vol).groupby(day).cumsum().values
    vw = np.where(vv > 0, pv / np.maximum(vv, 1e-9), np.nan); out["vwap_stretch"] = (C.close.values[k] / vw[k] - 1) * 1e4 * d
    tb = C.taker_buy.values; cv = np.nancumsum(vol); cb = np.nancumsum(np.nan_to_num(tb))
    imb = ((2 * (cb[k] - cb[k - 15]) - (cv[k] - cv[k - 15])) / np.maximum(cv[k] - cv[k - 15], 1e-9)) * d
    out["taker_15m"] = np.where(np.isnan(tb[k]), np.nan, imb)                     # + = takers pushing WITH the bet (from 1 Oct)
    return pd.DataFrame(out, index=bets.index)

def slide_base(bets, C):
    """SLIDE (family G): the 4h OsMA(3,10,16) run on the bet's side (negative = against the bet for N bars) and G1 = 15m BBW50 / its 24-bar median <= 0.80
    with that run <= -9."""
    c = C.set_index("t").close; d = bets.d.values
    def g(step):
        x = c.groupby(c.index // step * step).last(); return x, np.searchsorted(x.index.values + step, bets.P.values, side="right") - 1
    c4, j4 = g(14400); mm = c4.ewm(span=3, adjust=False).mean() - c4.ewm(span=10, adjust=False).mean(); os_ = mm - mm.ewm(span=16, adjust=False).mean()
    sg = np.sign(os_.values); run = np.ones(len(sg))
    for i in range(1, len(sg)): run[i] = run[i - 1] + 1 if (sg[i] == sg[i - 1] and sg[i] != 0) else 1
    orun = (sg * run)[j4] * d
    c15, j15 = g(900); bw = 4 * c15.rolling(50).std(ddof=0) / c15.rolling(50).mean(); r15 = (bw / bw.rolling(24, min_periods=12).median()).values[j15]
    return orun, (orun <= -9) & (r15 <= 0.80)

def vr_er(bets, C):
    t = C.t.values; lp = np.log(C.close.values); r1 = np.diff(lp, prepend=np.nan); r5 = np.r_[np.full(5, np.nan), lp[5:] - lp[:-5]]
    vr = pd.Series(r5).rolling(240, min_periods=192).var(ddof=0).values / (5 * pd.Series(r1).rolling(240, min_periods=192).var(ddof=0).values)
    er = np.abs(lp - np.r_[np.full(12, np.nan), lp[:-12]]) / pd.Series(np.abs(r1)).rolling(12).sum().values
    k = np.searchsorted(t + 60, bets.P.values, side="right") - 1
    return vr[k], er[k]

def main():
    A = args(); t0 = time.time()
    bets = pd.read_csv("bets.csv"); C = pd.read_csv("btc_1m.csv.gz").sort_values("t").reset_index(drop=True)
    C = C.set_index("t").reindex(pd.RangeIndex(C.t.min(), C.t.max() + 60, 60)); C[["open", "high", "low", "close"]] = C[["open", "high", "low", "close"]].interpolate(limit=10)
    C = C.dropna(subset=["close"]).reset_index().rename(columns={"index": "t"})
    PENNY = {"snap", "penny", "volume", "lean", "wide", "wick", "zap", "deep", "sam", "slip", "dip", "dart", "x12", "pearl", "chop", "ruby", "duo"}
    keep = (((bets.set != "live") & bets.kept) | ((bets.set == "live") & ((A.live == "all") | bets.kept))) & ~bets.leg.isin(PENNY)   # 15c+ legs only
    bets = bets[keep].reset_index(drop=True)
    vr, er = vr_er(bets, C); burst = (vr > A.vr) & (er >= A.er)
    if A.group == "slide":
        orun, g1 = slide_base(bets, C)
        sel = (orun <= -A.slide_run) & ~g1
        print("slide base: %d bets with the 4h OsMA against the bet >= %d bars (%d more already held by G1, left out)" % (int(sel.sum()), A.slide_run, int(((orun <= -A.slide_run) & g1).sum())))
    else:
        sel = burst if A.group == "burst" else (~burst if A.group == "calm" else np.ones(len(bets), bool))
    bets = bets[sel].reset_index(drop=True)
    sets = ["history", "replay", "live"]; mins = {"history": A.min_hist, "replay": A.min_replay, "live": A.min_live}
    print("group '%s' (burst = VR > %.2f and ER >= %.2f): %s" % (A.group, A.vr, A.er, {s: int((bets.set == s).sum()) for s in sets}))
    print("their result: %s" % {s: round(bets.pnl[bets.set == s].sum(), 2) for s in sets})
    X = build(bets, C); print("indicators: %d (%.0f s)" % (X.shape[1], time.time() - t0))
    Q = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9); conds = []; idx = {}
    for f in X.columns:
        v = X[f].values.astype(float)
        if np.isnan(v).mean() > 0.5 or np.nanstd(v) == 0: continue
        for qi, q in enumerate(Q):
            th = float(np.nanquantile(v, q))
            for op in ("<=", ">="):
                m = np.nan_to_num((v <= th) if op == "<=" else (v >= th), nan=0).astype(np.float32)
                idx[(f, op, qi)] = len(conds); conds.append((f, op, qi, th, m))
    M = np.vstack([c[4] for c in conds]); pn = bets.pnl.values.astype(np.float32); lose = (pn < 0).astype(np.float32)
    S = {s: (bets.set == s).values.astype(np.float32) for s in sets}
    print("conditions: %d" % len(conds))
    def stats_single():
        out = {}
        for s in sets:
            ms = M * S[s]; out[s] = (ms.sum(1), ms @ pn, ms @ lose)
        return out
    st = stats_single(); rows = []
    def passes(cnt, pnl, los, relax=False):
        for s in sets:
            n = cnt[s]; 
            if pnl[s] > 0: return False                                             # held bets made money -> holding them costs
            if not relax and (n < mins[s] or (n > 0 and los[s] / n < A.min_losers)): return False
        return True
    for i, (f, op, qi, th, _) in enumerate(conds):
        cnt = {s: st[s][0][i] for s in sets}; pnl = {s: st[s][1][i] for s in sets}; los = {s: st[s][2][i] for s in sets}
        if passes(cnt, pnl, los):
            nb = [idx.get((f, op, qi + dq)) for dq in (-1, 1)]; nb = [x for x in nb if x is not None]
            rob = np.mean([passes({s: st[s][0][x] for s in sets}, {s: st[s][1][x] for s in sets}, {s: st[s][2][x] for s in sets}, relax=True) for x in nb]) if nb else 0
            rows.append(("%s %s %.4g" % (f, op, th), "", rob, cnt, pnl, los))
    if not A.no_pairs:
        P = {}
        for s in sets:
            ms = M * S[s]; P[s] = (ms @ M.T, (ms * pn) @ M.T, (ms * lose) @ M.T)
        ok = np.ones(P["history"][0].shape, bool)
        for s in sets:
            cnt, pnl, los = P[s]; ok &= (pnl <= 0) & (cnt >= mins[s]) & ((cnt == 0) | (los >= A.min_losers * cnt))
        names = np.array([c[0] for c in conds], dtype=object); ok &= (names[:, None] != names[None, :]); ok &= np.triu(np.ones(ok.shape, bool), 1)
        for i, j in zip(*np.where(ok)):
            fi, oi, qi = conds[i][:3]; fj, oj, qj = conds[j][:3]; nb = []
            for di_, dj_ in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                a_ = idx.get((fi, oi, qi + di_)); b_ = idx.get((fj, oj, qj + dj_))
                if a_ is not None and b_ is not None: nb.append(all(P[s][1][a_, b_] <= 0 for s in sets))
            rows.append(("%s %s %.4g" % (fi, oi, conds[i][3]), "%s %s %.4g" % (fj, oj, conds[j][3]), float(np.mean(nb)) if nb else 0.0,
                         {s: P[s][0][i, j] for s in sets}, {s: P[s][1][i, j] for s in sets}, {s: P[s][2][i, j] for s in sets}))
    R = pd.DataFrame([{"condition_1": a, "condition_2": b, "neighbours_pass": round(r, 2),
                       **{"%s_held" % s: int(c[s]) for s in sets}, **{"%s_losers_pct" % s: round(100 * l[s] / max(c[s], 1)) for s in sets},
                       **{"%s_saves" % s: round(-float(p[s]), 2) for s in sets}, "total_saves": round(-sum(float(p[s]) for s in sets), 2)}
                      for a, b, r, c, p, l in rows])
    if len(R):
        R = R.sort_values(["neighbours_pass", "total_saves"], ascending=[False, False]); R.to_csv("hunt_results.csv", index=False)
        print("\nPASSED: %d rules (%d with ALL neighbours passing). Top %d:" % (len(R), int((R.neighbours_pass == 1).sum()), A.top))
        for _, r in R.head(A.top).iterrows():
            print("  [%3.0f%% nb] %s%s | hist %d/%+.2f | replay %d/%+.2f | live %d/%+.2f | TOTAL %+.2f" % (100 * r.neighbours_pass, r.condition_1, (" + " + r.condition_2) if r.condition_2 else "",
                  r.history_held, r.history_saves, r.replay_held, r.replay_saves, r.live_held, r.live_saves, r.total_saves))
    else:
        print("\nno rule passed with these settings -- try --min-losers 0.6 or smaller minimums")
    print("done in %.0f s; saved hunt_results.csv" % (time.time() - t0))

if __name__ == "__main__":
    main()
