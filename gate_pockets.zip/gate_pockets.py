"""gate_pockets.py -- PROFIT / RISK POCKETS, top-down like FLAT: 4-hour regimes first (bird's-eye view), then drill down (1h / 15m / 5m / 1m).

Input: pockets_population.csv = every RAW standard-leg trade (no Violent / LEG / breaker filters) with its result, whether the current bot
(v9.02d-10) keeps it ('kept'), its entry and the highest bid it reached after the fill ('maxbid', from the real price paths).

Three kinds of pocket, each judged in history AND replay AND live, +-10% stable, and with a WALK-FORWARD (found on history only, checked after):
  STRONG  -- raw trades clearly better than the raw baseline -> the bot's OWN trades inside: what 1.5x / 2x shares would add, and the worst day.
  WEAK    -- raw trades clearly worse (and losing) -> the bot's own trades inside: SKIP (money saved, fills lost) vs a 69c EXIT (real paths).
  NEUTRAL -- the bot's own trades in NO strong / weak pocket -> a 75c take-profit vs the normal exit (85c BIRD, 98c others), overall and per leg.

Run on the PC from C:\\tmp (unzip this folder there):   aitv\\Scripts\\python gate_pockets.py
Options: --step 0.1 (0.05 finer) --triples 300 (0 = off) --regimes 8 --drills 3 --workers N --out gate_pockets_out
         --strong-margin 0.40 --weak-margin 0.40 --drill-margin 0.30 (avg $ per trade above / below the baseline in EVERY period)
Send back gate_pockets_out\\ : summary.txt (start here), strong.csv, weak.csv, neutral.csv, walkforward.csv.
"""
import argparse, glob, os, sys, time, warnings
from multiprocessing import Pool
import numpy as np, pandas as pd
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rule_hunter as rh

PER = ("history", "replay", "live")
Q = 6.0


def candles(pat):
    d = pd.read_csv(glob.glob(pat.format(coin="BTC"))[0]).rename(columns={"open_time": "t"}); d["taker_buy"] = np.nan
    d = d.set_index("t").sort_index(); d = d.reindex(pd.RangeIndex(d.index.min(), d.index.max() + 60, 60))
    d[["open", "high", "low", "close"]] = d[["open", "high", "low", "close"]].interpolate(limit=10)
    return d.dropna(subset=["open", "high", "low", "close"]).reset_index().rename(columns={"index": "t"})


def features(pop, C):
    X = rh.build(pop[["P", "d"]].reset_index(drop=True), C)
    step = 14400; g = C.assign(g=C.t // step * step).groupby("g").agg(o=("open", "first"), h=("high", "max"), l=("low", "min"), c=("close", "last"), v=("volume", "sum"), n=("close", "size"))
    g = g[g.n >= step // 60]; te = g.index.values + step; j = np.searchsorted(te, pop.P.values, side="right") - 1; ok = j >= 0; j = np.clip(j, 0, None); d = pop.d.values
    F4 = {}
    for k, (arr, kind) in rh.tf_features(g).items():
        v = np.where(ok, arr[j], np.nan); F4["%s_4h" % k] = np.where(d > 0, v, 100 - v) if kind == "osc" else (v * d if kind == "sgn" else v)
    return X.drop(columns=[c for c in X.columns if c in ("vwap_stretch", "taker_15m")]), pd.DataFrame(F4)


def variants(c, th):
    if "supertrend" in c:
        return []
    if "flip" in c or (float(th).is_integer() and abs(th) <= 10):
        return [th - 1, th + 1]
    return [th * 0.9, th * 1.1] if th != 0 else [-0.01, 0.01]


def conds_for(XV, rows, step, cov=(0.05, 0.6)):
    out = []
    for c, v in XV.items():
        vr = v[rows]
        if np.isfinite(vr).mean() < 0.8 or np.nanstd(vr) == 0:
            continue
        for th in np.unique(np.nanquantile(vr, np.arange(step, 1.0 - 1e-9, step))):
            for op in ("<=", ">="):
                m = np.nan_to_num((vr <= th + 1e-9) if op == "<=" else (vr >= th - 1e-9), nan=0).astype(bool)
                if cov[0] <= m.mean() <= cov[1]:
                    out.append((c, op, float(th), m))
    return out


def mask(XV, parts, rows):
    m = np.ones(len(rows), bool)
    for c, op, th in parts:
        v = XV[c][rows]; m &= np.nan_to_num((v <= th + 1e-9) if op == "<=" else (v >= th - 1e-9), nan=0).astype(bool)
    return m


def passes(pn, per, m, ref, margin, mins, kind, wfac=1.0):
    """kind 'strong': avg >= ref + margin AND win >= ref win + 6 pts; 'weak': avg <= min(0, ref - margin) AND win <= ref win - 5 pts -- every period."""
    for p, mn in zip(PER, mins):
        k = m & (per == p); n = int(k.sum())
        if n < mn:
            return False
        a = pn[k].mean(); w = (pn[k] > 0).mean()
        if kind == "strong" and (a < ref[p][0] + margin or w < ref[p][1] + 0.06 * wfac):
            return False
        if kind == "weak" and (a > min(0.0, ref[p][0] - margin) or w > ref[p][1] - 0.05 * wfac):
            return False
    return True


def search(XV, rows, pn, per, ref, margin, mins, kind, step, triples, cap, cov=(0.05, 0.6), names=None):
    """Singles / pairs (+ triples) over the conditions on `rows`; +-10% stable; distinct trade sets; best first."""
    pn_r = pn[rows]; per_r = per[rows]; win = (pn_r > 0).astype(np.float32)
    C = conds_for({k: v for k, v in XV.items() if names is None or k in names}, rows, step, cov)
    if len(C) < 2:
        return []
    M = np.vstack([q[3] for q in C]).astype(np.float32); G = {p: (per_r == p).astype(np.float32) for p in PER}
    N = {p: (M * G[p]) @ M.T for p in PER}; S = {p: ((M * G[p]) * pn_r) @ M.T for p in PER}; W = {p: ((M * G[p]) * win) @ M.T for p in PER}
    ok = np.ones(N["history"].shape, bool)
    for p, mn in zip(PER, mins):
        n = np.maximum(N[p], 1); a = S[p] / n; w = W[p] / n; ok &= N[p] >= mn
        ok &= (a >= ref[p][0] + margin) & (w >= ref[p][1] + 0.06) if kind == "strong" else (a <= min(0.0, ref[p][0] - margin)) & (w <= ref[p][1] - 0.05)
    nm = np.array([q[0] for q in C], dtype=object); ok &= ((nm[:, None] != nm[None, :]) | np.eye(len(C), dtype=bool)) & np.triu(np.ones(ok.shape, bool))
    tot = sum(S[p] for p in PER); sign = -1 if kind == "strong" else 1
    ij = np.argwhere(ok); ij = ij[np.argsort(sign * tot[ij[:, 0], ij[:, 1]])]
    cands = [[C[a][:3]] + ([] if a == b else [C[b][:3]]) for a, b in ij[:4000]]
    if triples > 0:
        tp = np.argwhere(np.triu(np.ones(tot.shape, bool), 1) & (nm[:, None] != nm[None, :]) & (N["history"] >= mins[0]))
        tp = tp[np.argsort(sign * tot[tp[:, 0], tp[:, 1]])][:triples]
        for a, b in tp:
            mab = M[a] * M[b]
            for k in range(len(C)):
                if C[k][0] in (C[a][0], C[b][0]):
                    continue
                m = (mab * M[k]).astype(bool)
                if passes(pn_r, per_r, m, ref, margin, mins, kind):
                    cands.append([C[a][:3], C[b][:3], C[k][:3]])
    out = []; seen = set()
    for parts in cands:
        m = mask(XV, parts, rows)
        key = m.tobytes()
        if key in seen or not passes(pn_r, per_r, m, ref, margin, mins, kind):
            continue
        seen.add(key); st = True
        for i, (c, op, th) in enumerate(parts):
            for t2 in variants(c, th):
                pp = list(parts); pp[i] = (c, op, t2)
                if not passes(pn_r, per_r, mask(XV, pp, rows), ref, margin * 0.6, tuple(int(x * 0.75) for x in mins), kind, wfac=0.6):   # +-10%: both margins x0.6
                    st = False; break
            if not st:
                break
        if st:
            out.append((parts, m))
        if len(out) >= cap:
            break
    out.sort(key=lambda z: sign * pn_r[z[1]].sum())
    return out


def distinct(found, k, maxj=0.5):
    pick = []
    for parts, m in found:
        if all((m & m2).sum() / max((m | m2).sum(), 1) <= maxj for _, m2 in pick):
            pick.append((parts, m))
        if len(pick) >= k:
            break
    return pick


def drill_job(job):
    """One regime: drill down with lower-timeframe conditions (singles + pairs of DIFFERENT timeframes)."""
    rid, kind, rows_idx, XV, pn, per, a = job
    rows = rows_idx; ref = {p: (pn[rows][per[rows] == p].mean(), (pn[rows][per[rows] == p] > 0).mean()) for p in PER}
    lower = [c for c in XV if not c.endswith("_4h")]
    found = search(XV, rows, pn, per, ref, a.drill_margin, (60, 10, 6), kind, a.step, 0, 150, cov=(0.15, 0.8), names=set(lower))
    found = [(p, m) for p, m in found if len({c.rsplit("_", 1)[1] for c, _, _ in p}) == len(p)]
    return rid, [(parts, rows[m]) for parts, m in distinct(found, a.drills)]


def exit_val(maxbid, win, level):
    return np.where(maxbid >= level, level, win.astype(float))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pop", default="pockets_population.csv"); ap.add_argument("--recent", default="recent_1m/{coin}_recent_1m.csv.gz")
    ap.add_argument("--step", type=float, default=0.1); ap.add_argument("--triples", type=int, default=300); ap.add_argument("--regimes", type=int, default=8)
    ap.add_argument("--drills", type=int, default=3); ap.add_argument("--strong-margin", dest="strong_margin", type=float, default=0.40)
    ap.add_argument("--weak-margin", dest="weak_margin", type=float, default=0.40); ap.add_argument("--drill-margin", dest="drill_margin", type=float, default=0.30)
    ap.add_argument("--cut", default="2026-10-15"); ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1)); ap.add_argument("--out", default="gate_pockets_out")
    a = ap.parse_args(); t0 = time.time(); os.makedirs(a.out, exist_ok=True)
    pop = pd.read_csv(a.pop); C = candles(a.recent)
    print("population %d raw trades (%d kept by the bot) | DATA CHECK candles end %s" % (len(pop), int(pop.kept.sum()), pd.to_datetime(C.t.max() + 60, unit="s")))
    X, F4 = features(pop, C); XV = {c: X[c].values.astype(float) for c in X.columns}; XV.update({c: F4[c].values.astype(float) for c in F4.columns})
    names4 = set(F4.columns); pn = pop.pnl.values; per = pop.period.values; kept = pop.kept.values.astype(bool); allrows = np.arange(len(pop))
    ref = {p: (pn[per == p].mean(), (pn[per == p] > 0).mean()) for p in PER}
    base_exit = np.where(pop.leg.values == "BIRD", 0.85, 0.98); mb = pop.maxbid.fillna(0).values; win = pop.win.values
    v_base = exit_val(mb, win, base_exit); v69 = exit_val(mb, win, 0.69); v75 = exit_val(mb, win, 0.75)
    day = pd.to_datetime(pop.P, unit="s").dt.date.values; daily = pd.Series(np.where(kept, pn, 0.0)).groupby(day).sum()
    summ = ["GATE POCKETS -- %s -- %d raw trades, step %.2f, triples %d, %d indicators (%d at 4h)" % (time.strftime("%Y-%m-%d %H:%M"), len(pop), a.step, a.triples, len(XV), len(names4)),
            "raw baseline: " + " | ".join("%s %.1f%% %+.2f" % (p, ref[p][1] * 100, ref[p][0]) for p in PER), ""]
    out = {}
    for kind, margin in (("strong", a.strong_margin), ("weak", a.weak_margin)):
        R = distinct(search(XV, allrows, pn, per, ref, margin, (150, 40, 15), kind, a.step, a.triples, 400, names=names4), a.regimes)
        print("%s 4h regimes: %d (%.0fs)" % (kind, len(R), time.time() - t0))
        jobs = [("%s-%d" % (kind[0].upper(), i + 1), kind, allrows[m], XV, pn, per, a) for i, (parts, m) in enumerate(R)]
        with Pool(a.workers) as pool:
            dr = dict(pool.map(drill_job, jobs, chunksize=1))
        out[kind] = [(("%s-%d" % (kind[0].upper(), i + 1)), parts, allrows[m], dr.get("%s-%d" % (kind[0].upper(), i + 1), [])) for i, (parts, m) in enumerate(R)]
    rows_s, rows_w = [], []; inS = np.zeros(len(pop), bool); inW = np.zeros(len(pop), bool)
    def stat(idx):
        return " | ".join("%s %dt %.0f%% %+.2f" % (p[0].upper(), int((per[idx] == p).sum()), ((pn[idx][per[idx] == p] > 0).mean() * 100 if (per[idx] == p).any() else 0), (pn[idx][per[idx] == p].mean() if (per[idx] == p).any() else 0)) for p in PER)
    for kind in ("strong", "weak"):
        summ.append("=== %s POCKETS (4h regime -> drill-down) ===" % kind.upper())
        for rid, parts, ridx, drills in out[kind]:
            summ.append("%s  4h: %s  [%s]" % (rid, " + ".join("%s %s %.4g" % p for p in parts), stat(ridx)))
            for j, (dp, didx) in enumerate([(None, ridx)] + drills):
                name = rid if dp is None else "%s.%d" % (rid, j)
                k = didx[kept[didx]]
                if kind == "strong":
                    inS[k] = True
                    g15 = {p: 0.5 * pn[k][per[k] == p].sum() for p in PER}; g2 = {p: pn[k][per[k] == p].sum() for p in PER}
                    d2 = (pd.Series(np.where(kept, pn, 0.0) + np.where(np.isin(allrows, k), pn, 0.0)).groupby(day).sum()).min()
                    line = "   %-7s %s | bot's own %d trades %s | 1.5x adds %+.2f  2x adds %+.2f | worst day %+.2f -> %+.2f (2x)" % (name, ("" if dp is None else "+ " + " + ".join("%s %s %.4g" % p for p in dp)), len(k), stat(k), sum(g15.values()), sum(g2.values()), daily.min(), d2)
                    rows_s.append({"pocket": name, "regime": " + ".join("%s %s %.6g" % p for p in parts), "drill": "" if dp is None else " + ".join("%s %s %.6g" % p for p in dp), "raw_trades": len(didx), "bot_trades": len(k),
                                   **{"bot_%s_avg" % p: (pn[k][per[k] == p].mean() if (per[k] == p).any() else np.nan) for p in PER}, "add_1p5x": sum(g15.values()), "add_2x": sum(g2.values()), "worst_day_2x": d2})
                else:
                    inW[k] = True
                    sk = {p: -pn[k][per[k] == p].sum() for p in PER}; e69 = {p: ((v69[k] - v_base[k]) * Q)[per[k] == p].sum() for p in PER}
                    best = "SKIP" if sum(sk.values()) >= sum(e69.values()) else "69c"
                    line = "   %-7s %s | bot's own %d trades %s | SKIP %+.2f (fills -%d) | 69c EXIT %+.2f | better: %s" % (name, ("" if dp is None else "+ " + " + ".join("%s %s %.4g" % p for p in dp)), len(k), stat(k), sum(sk.values()), len(k), sum(e69.values()), best if max(sum(sk.values()), sum(e69.values())) > 0 else "neither")
                    rows_w.append({"pocket": name, "regime": " + ".join("%s %s %.6g" % p for p in parts), "drill": "" if dp is None else " + ".join("%s %s %.6g" % p for p in dp), "raw_trades": len(didx), "bot_trades": len(k),
                                   **{"skip_%s" % p: sk[p] for p in PER}, **{"exit69_%s" % p: e69[p] for p in PER}, "better": best})
                summ.append(line)
        summ.append("")
    neu = kept & ~inS & ~inW; e75 = (v75 - v_base) * Q
    summ.append("=== NEUTRAL (bot's own trades in no strong / weak pocket): %d trades -- 75c take-profit vs the normal exit ===" % int(neu.sum()))
    summ.append("   ALL: " + " | ".join("%s %+.2f" % (p, e75[neu & (per == p)].sum()) for p in PER) + " | TOTAL %+.2f" % e75[neu].sum())
    nrows = []
    for leg in sorted(set(pop.leg[neu])):
        m = neu & (pop.leg.values == leg); s = {p: e75[m & (per == p)].sum() for p in PER}
        nrows.append({"leg": leg, "trades": int(m.sum()), **{"exit75_%s" % p: s[p] for p in PER}, "total": sum(s.values()), "every_period_positive": all(v > 0 for v in s.values())})
        summ.append("   %-8s %4d trades: %s | TOTAL %+.2f%s" % (leg, int(m.sum()), " | ".join("%s %+.2f" % (p[0].upper(), s[p]) for p in PER), sum(s.values()), "  <- 75c better in EVERY period" if all(v > 0 for v in s.values()) else ""))
    cut = pd.Timestamp(a.cut).value // 10**9; pre = (pop.P.values < cut); wf = []
    pidx = allrows[pre]; o = np.argsort(pop.P.values[pidx]); per_wf = per.copy(); n = len(pidx)
    lab = np.empty(n, dtype=object); lab[o] = np.where(np.arange(n) < int(n * 0.6), "history", np.where(np.arange(n) < int(n * 0.8), "replay", "live")); per_wf[pidx] = lab
    ref_wf = {p: (pn[pidx][lab == p].mean(), (pn[pidx][lab == p] > 0).mean()) for p in PER}; post = ~pre; bpost = pn[post].mean()
    summ += ["", "=== WALK-FORWARD (4h regimes picked on trades BEFORE %s only, then checked after; raw baseline after %+.2f) ===" % (a.cut, bpost)]
    for kind, margin in (("strong", a.strong_margin), ("weak", a.weak_margin)):
        R = distinct(search(XV, pidx, pn, per_wf, ref_wf, margin, (100, 25, 25), kind, a.step, 0, 200, names=names4), a.regimes)
        good = 0
        for parts, m in R:
            idx = pidx[m]; mm = np.zeros(len(pop), bool); mm[idx] = True
            later = np.ones(len(pop), bool)
            for c, op, th in parts:
                v = XV[c]; later &= np.nan_to_num((v <= th + 1e-9) if op == "<=" else (v >= th - 1e-9), nan=0).astype(bool)
            q = later & post; av = pn[q].mean() if q.sum() else np.nan; ok = (av > bpost) if kind == "strong" else (av < bpost)
            good += bool(ok); wf.append({"kind": kind, "regime": " + ".join("%s %s %.6g" % p for p in parts), "post_trades": int(q.sum()), "post_avg": av, "holds_up": bool(ok)})
        summ.append("   %s: %d regimes picked before the cut -> %d (%.0f%%) still %s the baseline after it" % (kind, len(R), good, 100.0 * good / max(len(R), 1), "beat" if kind == "strong" else "below"))
    pd.DataFrame(rows_s).to_csv(os.path.join(a.out, "strong.csv"), index=False); pd.DataFrame(rows_w).to_csv(os.path.join(a.out, "weak.csv"), index=False)
    pd.DataFrame(nrows).to_csv(os.path.join(a.out, "neutral.csv"), index=False); pd.DataFrame(wf).to_csv(os.path.join(a.out, "walkforward.csv"), index=False)
    summ.append("\nDONE in %.1f min" % ((time.time() - t0) / 60))
    open(os.path.join(a.out, "summary.txt"), "w", encoding="utf-8").write("\n".join(summ) + "\n"); print("\n".join(summ))


if __name__ == "__main__":
    main()
