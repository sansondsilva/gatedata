# GATE ARCHIVE — 2026-AUG (one month of the 22 Oct 2026 sync)
Split from the full archive (sync22, everything to 22 Oct 2026 01:00 UTC) by calendar month, UTC. The three monthly zips together = the full archive,
row for row (verified). Join months by simply concatenating the files of the same name (they share columns; rows are time-ordered within each file).
- ledger_2026-AUG.csv.gz — laptop A's logged actions (orders, fills, results, holds, shadows): 16,222 rows, 24 Aug 20:03 → 31 Aug 20:30. Columns _sess (log set), _era (version band).
- ticks_5m_2026-AUG.csv.gz / ticks_15m_2026-AUG.csv.gz — the bot's per-poll market snapshots (prices, books, RSI, OsMA …).
- btc/eth/sol/xrp_1m_2026-AUG.csv.gz — official Binance 1m candles (open_time in seconds; OHLC + volume): 07 Aug 23:59 → 31 Aug 23:59, no gaps.
- klines_full/ -- {coin}_klines_full_{1m|5m}_2026-AUG.csv.gz: the same candles with these Binance columns: open_time, OHLC, volume, quote_volume, trades.
  (taker_buy_base / taker_buy_quote REMOVED from every month on 2 Nov: the downloads stopped carrying them on 31 Oct 06:40 and nothing uses them.)
- 2 Nov clean-up: btc/eth/sol/xrp_fairup REMOVED from the 15m ticks in every month (the bot stopped writing them; empty all of October and November, partial in September; nothing uses them).
