# New 'moderate' OPAL-5 rules — PC search

Periods: FOUND 2026-08-24,2026-09-28 | CONFIRM 2026-09-28,2026-10-13 | CHECK 2026-10-13,2026-10-20. Only NEW ground (existing OPAL rules and Violent-held bets left out).

**3 patterns PASS** of 1905 tested. LUCK TEST (20 time-shifted runs): [1, 1, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 6, 6, 7, 7, 7, 8, 9, 10] -> average 4.8; chance of 3+ by luck: 85%

| family | pattern - bet | FOUND fills | FOUND $ | edge c/share | CONFIRM fills | CONFIRM $ | CHECK fills | CHECK $ |
|---|---|---|---|---|---|---|---|---|
| F4 size x3 | R-S-G-M-G-M|follow | 28 | +15.78 | +6.8 | 9 | +10.38 | 6 | +0.18 |
| F4 size x3 | G-M-R-M-G-T|fade | 27 | +11.82 | +8.1 | 21 | +12.84 | 5 | +0.66 |
| F4 size x3 | G-M-G-M-R-S|fade | 25 | +11.28 | +8.4 | 8 | +1.50 | 2 | +1.86 |

Pattern key: per candle (1 = the last closed): dr G/R, sz T tiny < 0.3 ATR / S < 0.7 / M < 1.3, cp b bottom / m middle / t top third, ins i inside / o not; rz RSI lo < 40 / mid / hi > 60; btc1 BTC's last candle. Bet: follow = with the last candle, fade = against it.
