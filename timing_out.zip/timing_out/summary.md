# timing_sim summary (2026-10-27 12:29)

- jobs: 400 | real survivors: 14 | by chance (null runs): mean 0.8, max 8

- scoring: lift of P(win | dip) over the coin + direction's ordinary dips; dip = 1.0 one-minute sigmas against within 2 min

| family | params | context | bet | dips | win given dip | base | lift | z | quarters | up m | down m | coins |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| div | 30 | none | UP | 38490 | 31.1% | 27.5% | +3.6 | 15.7 | 8 | +3.5 | +3.6 | 4 |
| bb | true | none | UP | 11074 | 31.2% | 27.5% | +3.6 | 8.6 | 8 | +3.8 | +3.5 | 4 |
| rsi | [7, 20] | none | UP | 5437 | 32.5% | 27.5% | +5.0 | 8.2 | 8 | +5.7 | +4.2 | 4 |
| rsi | [7, 25] | none | UP | 9366 | 31.0% | 27.5% | +3.5 | 7.6 | 8 | +3.8 | +3.1 | 4 |
| rsi | [3, 10] | none | UP | 9832 | 30.8% | 27.5% | +3.3 | 7.3 | 8 | +3.8 | +2.7 | 4 |
| combo | [15, 25] | none | DOWN | 4038 | 31.0% | 27.3% | +3.8 | 5.4 | 7 | +2.5 | +5.3 | 4 |
| combo | [15, 15] | none | DOWN | 2690 | 31.6% | 27.3% | +4.3 | 5.1 | 7 | +3.5 | +5.5 | 4 |
| osma | [15, "first", 0.3] | none | DOWN | 5046 | 30.3% | 27.3% | +3.0 | 4.8 | 7 | +2.0 | +4.2 | 4 |
| combo | [15, 20] | none | DOWN | 3416 | 30.9% | 27.3% | +3.6 | 4.8 | 6 | +2.6 | +4.9 | 4 |
| combo | [12, 15] | none | DOWN | 3728 | 30.3% | 27.3% | +3.1 | 4.2 | 6 | +2.3 | +4.0 | 3 |
| osma | [18, "first", 0.3] | none | DOWN | 3479 | 30.3% | 27.3% | +3.0 | 4.0 | 7 | +1.9 | +4.4 | 4 |
| combo | [21, 20] | none | UP | 2138 | 30.8% | 27.5% | +3.3 | 3.4 | 7 | +2.7 | +4.1 | 4 |
| combo | [21, 15] | none | UP | 1699 | 31.2% | 27.5% | +3.7 | 3.4 | 6 | +3.3 | +4.2 | 4 |
| combo | [21, 25] | none | DOWN | 1981 | 30.4% | 27.3% | +3.1 | 3.1 | 7 | +2.2 | +4.4 | 4 |

Send back: summary.md + survivors.csv (zip).