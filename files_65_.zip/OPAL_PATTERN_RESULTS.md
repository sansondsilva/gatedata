# OPAL pattern search: results (session of 17 Oct 2026, from PATTERN_RESEARCH_BRIEF.md)

**Data:** `binance_2y` (Oct 2024 → Sep 2026, 4 coins). The Polymarket check uses the archive's ticks (24 Aug → 13 Oct 2026); candles for 1–13 Oct come from the archive's `*_klines_full_5m.csv`, which match `binance_2y` exactly where they overlap.

**Reproduction first:**
- The confirmed set in §7 reproduces exactly, including every Polymarket figure.
- Two small differences: `RT RM RS` has n = 674 here (673 in the brief), and `GT RM RM +engulf` priced 26 trades here (27 in the brief), so the family union is 154 trades, +$82.35.
- Engulf-anywhere means each pattern candle against its own predecessor, the first candle included; that is the definition that reproduces the brief's counts.

## Search accounting

Chance is measured with a **cross-coin null**: every coin's outcome series is shifted circularly by the same random offset (20 runs). This keeps the coins' correlation, so it shows what chance produces at this bar with real data, not only under independence.

| Search | Tested (n ≥ 150) | Pass bar 1–4 | Chance survivors (null mean) |
|---|---|---|---|
| Previous session's searches, re-run (2c full ± C2>C1, 3c coarse ± engulf; 5m + 15m) | 4,319 | 17 | 0.50 |
| S1: 15m 4-candle coarse ± engulf | 101 | 0 (best z 2.8) | 0.00 |
| S2: 15m 3c × inner 5m candles (last 5m coarse / inner colours / last 5m wicks) | 229 + 355 + 4 | 0 (best z 3.8) | 0.00 |
| S3: 5m wick → full body, 3 candles (ignore / any / none) | 11 + 0 + 0 | 0 (best z 2.0) | 0.00 |
| S4: 2c full, engulf in either candle (5m: C1>C0 / any / none; 15m: same) | 186 + 526 + 1,238; 0 + 44 + 76 | 5 (all 5m, "none") | 0.20 for all new searches together |
| **New total** | **2,770** | **5** | **0.20** (independence alone: ~0.17) |

- **Bar 5 (Polymarket):** 4 of the 5 pass it. `R(L,UT,DT) -> R(M,UT,DS)` (UP) fails: 9 trades, 22% won, −$14.74.
- **Red runs of 4 (search direction 1):** red runs of 4 of any size, outside the family, pass bars 1–4 on candles (12,387 cases, 55.7%, z 12.6, 8/8 quarters, up months 57.0% / down 54.3%). They **fail on Polymarket**: 553 trades, 49% won, −$75.26. Red runs of 3 outside the family do the same: 1,252 trades, 49%, −$150.19.

  The generic reversal is not tradeable. Requiring an ask ≤ 0.60 leaves the worse half: the candle win rate falls from 54.9% for all signals to 51.9% for the priced ones. On top of that, the 15m candle-to-Polymarket gap is about 2–3 points (family 61.7% → 59.7%, runs 51.9% → 49.0%). Only the family's specific cells keep their edge. **No new 15m pattern passes.**

## New survivors (all 5m)

```
ID: OPAL5-02
TF: 5m
SEQUENCE (oldest -> newest): G(M,UT,DS) -> G(T,US,DM)
ENGULF: none
BET: DOWN (next 5m window)
TWO YEARS: n=291  win=62.9%  calibrated=~55.4%  quarters=8/8  up=61.3%  down=64.9%  per-coin: BTC 70.1% ETH 65.8% SOL 65.9% XRP 48.5%
POLYMARKET (archive): trades=7  win=71%  P&L=+$11.32
OVERLAP (5m only): 0 of 291 with AMBER / WOLF / VICTOR (all 7 archive trades are beyond the legs)
```

```
ID: OPAL5-03
TF: 5m
SEQUENCE (oldest -> newest): R(L,UT,DT) -> G(T,UM,DS)
ENGULF: none
BET: UP (next 5m window)
TWO YEARS: n=312  win=62.2%  calibrated=~54.7%  quarters=8/8  up=63.5%  down=60.9%  per-coin: BTC 53.1% ETH 68.3% SOL 54.5% XRP 69.7%
POLYMARKET (archive): trades=7  win=57%  P&L=+$2.38
OVERLAP (5m only): 0 of 312 with AMBER / WOLF / VICTOR (all 7 archive trades are beyond the legs)
```

```
ID: OPAL5-04
TF: 5m
SEQUENCE (oldest -> newest): R(M,UT,DM) -> R(S,US,DS)
ENGULF: none
BET: UP (next 5m window)
TWO YEARS: n=161  win=66.5%  calibrated=~59.0%  quarters=7/8  up=67.0%  down=65.8%  per-coin: BTC 60.6% ETH 64.1% SOL 81.6% XRP 60.8%
POLYMARKET (archive): trades=5  win=60%  P&L=+$1.26
OVERLAP (5m only): 22 of 161 (14%) with AMBER, same side; WOLF 0; VICTOR 0 (archive: 4 trades beyond the legs, -$1.87)
```

```
ID: OPAL5-05
TF: 5m
SEQUENCE (oldest -> newest): G(M,UT,DT) -> G(L,US,DT)
ENGULF: none
BET: DOWN (next 5m window)
TWO YEARS: n=298  win=62.1%  calibrated=~54.6%  quarters=8/8  up=59.6%  down=65.4%  per-coin: BTC 63.5% ETH 71.6% SOL 60.0% XRP 52.3%
POLYMARKET (archive): trades=12  win=58%  P&L=+$11.89
OVERLAP (5m only): 208 of 298 (70%) with AMBER (104) / VICTOR (176), all same side; WOLF 0 (archive: 3 trades beyond the legs, -$6.34)
```

## Python lists (starting set + new survivors)

```python
OPAL15_PATTERNS = [   # OPAL-15: 15m -> bet on the next 15m window
    {"id": "OPAL15-01", "seq": ["RS", "RS", "RS"], "engulf": "none", "bet": "UP"},
    {"id": "OPAL15-02", "seq": ["GT", "RM", "RM"], "engulf": "any", "bet": "UP"},
    {"id": "OPAL15-03", "seq": ["RM", "GT", "RL"], "engulf": "any", "bet": "UP"},
    {"id": "OPAL15-04", "seq": ["RS", "RM", "RM"], "engulf": "none", "bet": "UP"},
    {"id": "OPAL15-05", "seq": ["RT", "RT", "RL"], "engulf": "none", "bet": "UP"},
    {"id": "OPAL15-06", "seq": ["RS", "RS", "RM"], "engulf": "none", "bet": "UP"},
    {"id": "OPAL15-07", "seq": ["GT", "RL", "RM"], "engulf": "any", "bet": "UP"},
    {"id": "OPAL15-08", "seq": ["RT", "RM", "RS"], "engulf": "none", "bet": "UP"},
    {"id": "OPAL15-09", "seq": ["R(M,UT,DS)", "R(M,UT,DS)"], "engulf": "ignore", "bet": "UP"},
    {"id": "OPAL15-10", "seq": ["R(S,US,DS)", "R(M,UT,DS)"], "engulf": "ignore", "bet": "UP"},
]
OPAL5_PATTERNS = [    # OPAL-5: 5m -> bet on the next 5m window
    {"id": "OPAL5-01", "seq": ["G(M,UM,DT)", "G(L,UT,DT)"], "engulf": "ignore", "tag": "C1>C0", "bet": "DOWN"},
    {"id": "OPAL5-02", "seq": ["G(M,UT,DS)", "G(T,US,DM)"], "engulf": "none", "bet": "DOWN"},
    {"id": "OPAL5-03", "seq": ["R(L,UT,DT)", "G(T,UM,DS)"], "engulf": "none", "bet": "UP"},
    {"id": "OPAL5-04", "seq": ["R(M,UT,DM)", "R(S,US,DS)"], "engulf": "none", "bet": "UP"},
    {"id": "OPAL5-05", "seq": ["G(M,UT,DT)", "G(L,US,DT)"], "engulf": "none", "bet": "DOWN"},
]
```

`engulf: "none"` on a 2-candle pattern means **neither** candle engulfs its predecessor (C1 vs C0, C2 vs C1).

## Flags (the bar is unchanged; these are for the operator's decision)

- **Neighbouring cells** (one class step on either candle, same bet, n ≥ 50):
  - OPAL5-02 and OPAL5-03 are **isolated cells**: their neighbours' median win is 49.8% and 51.1%. This is what binding rule 6 calls "one lucky cell" rather than a plateau.
  - OPAL5-04 sits on a plateau: neighbours' median 55.2%.
  - OPAL5-05 is partly on one: neighbours' median 54.3%.
- **Per coin:**
  - OPAL5-02 fails on XRP (48.5%).
  - OPAL5-03 is carried by ETH and XRP (BTC 53.1%, SOL 54.5%).
  - Starting set: OPAL15-06 is 50.5% on SOL, and OPAL15-08 is 54.0% on BTC. Every other starting pattern is at least 55.8% on every coin.
- **Overlap:**
  - OPAL5-05 mostly duplicates AMBER and VICTOR (70%, same side). It is a near-twin of OPAL5-01: green M then green L, bet DOWN, with disjoint wick classes.
  - By the brief's simple definitions, OPAL5-01 itself overlaps 68% (AMBER 127, VICTOR 263, all same side); only 1 of its 14 archive trades falls outside. The brief's "+$10.98 beyond the legs" must have used another measure, perhaps the legs' actual trades.
  - The VICTOR rule given (a body ≥ 3× the 24-candle median) fires on about 8% of candles, so all VICTOR overlaps here are upper bounds.
- **Margins:** calibrated 5m rates of 54.6–55.4% (OPAL5-02, 03, 05) sit only a few points above the ~52–53% break-even of a 50c entry with fees. The Polymarket samples are 5–12 trades each.
- **Cleanest new addition:** OPAL5-04. It is on a plateau, every coin is at least 60.6%, and overlap is low. Its Polymarket sample is tiny (5 trades).
